from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class FlowSession:
    request_id: str
    mobile_number: str = ""
    name: str = ""
    input_mobile: str = ""
    input_name: str = ""
    captcha_txn_id: str = ""
    mode: str = "both"
    otp_txn_id: Optional[str] = None
    eid_number: Optional[str] = None
    download_captcha_txn_id: Optional[str] = None
    download_captcha_text: Optional[str] = None
    download_otp_txn_id: Optional[str] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class SessionStore:
    def __init__(self) -> None:
        self._sessions: dict[int, FlowSession] = {}

    def set(self, chat_id: int, session: FlowSession) -> None:
        self._sessions[chat_id] = session

    def get(self, chat_id: int) -> Optional[FlowSession]:
        return self._sessions.get(chat_id)

    def clear(self, chat_id: int) -> None:
        self._sessions.pop(chat_id, None)
