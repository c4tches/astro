"""Persistent per-user metrics and cooldown timestamps (JSON file)."""

from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

_ACTIVITY_MAX = 40


@dataclass
class UserMetrics:
    chat_id: int
    username: str | None = None
    full_name: str | None = None
    first_seen_unix: float = 0.0
    last_seen_unix: float = 0.0
    starts_count: int = 0
    pdf_downloads: int = 0
    eid_retrievals: int = 0
    last_success_unix: float | None = None
    activity: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict[str, Any], *, default_chat_id: int | None = None) -> UserMetrics:
        cid = d.get("chat_id", default_chat_id)
        if cid is None:
            raise ValueError("chat_id required")
        raw_act = d.get("activity")
        if not isinstance(raw_act, list):
            raw_act = []
        return cls(
            chat_id=int(cid),
            username=d.get("username"),
            full_name=d.get("full_name"),
            first_seen_unix=float(d.get("first_seen_unix") or 0),
            last_seen_unix=float(d.get("last_seen_unix") or 0),
            starts_count=int(d.get("starts_count") or 0),
            pdf_downloads=int(d.get("pdf_downloads") or 0),
            eid_retrievals=int(d.get("eid_retrievals") or 0),
            last_success_unix=float(d["last_success_unix"]) if d.get("last_success_unix") is not None else None,
            activity=[x for x in raw_act if isinstance(x, dict)][-_ACTIVITY_MAX:],
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class AnalyticsStore:
    def __init__(self, file_path: str) -> None:
        self._path = Path(file_path)
        self._lock = threading.Lock()
        self._users: dict[int, UserMetrics] = {}
        self._load()

    def _load(self) -> None:
        if not self._path.exists():
            return
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        users = raw.get("users") or {}
        for k, v in users.items():
            try:
                mid = int(k)
                if not isinstance(v, dict):
                    continue
                self._users[mid] = UserMetrics.from_dict(v, default_chat_id=mid)
            except (TypeError, ValueError, KeyError):
                continue

    def _save_unlocked(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"users": {str(k): u.to_dict() for k, u in self._users.items()}}
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="utf-8")
        tmp.replace(self._path)

    def _append_activity_unlocked(self, u: UserMetrics, action: str, detail: str | None = None) -> None:
        row: dict[str, Any] = {"t": time.time(), "action": action}
        if detail:
            row["detail"] = detail[:200]
        u.activity = (u.activity + [row])[-_ACTIVITY_MAX:]

    def touch_user(
        self,
        chat_id: int,
        *,
        username: str | None,
        full_name: str | None = None,
        record_start: bool = False,
    ) -> None:
        now = time.time()
        with self._lock:
            u = self._users.get(chat_id)
            if u is None:
                u = UserMetrics(
                    chat_id=chat_id,
                    username=username,
                    full_name=full_name,
                    first_seen_unix=now,
                    last_seen_unix=now,
                )
                self._users[chat_id] = u
            else:
                u.last_seen_unix = now
                if username:
                    u.username = username
                if full_name:
                    u.full_name = full_name
            if record_start:
                u.starts_count += 1
                self._append_activity_unlocked(u, "start", "bot menu opened")
            self._save_unlocked()

    def append_event(self, chat_id: int, action: str, detail: str | None = None) -> None:
        with self._lock:
            u = self._users.get(chat_id)
            if u is None:
                now = time.time()
                u = UserMetrics(chat_id=chat_id, first_seen_unix=now, last_seen_unix=now)
                self._users[chat_id] = u
            u.last_seen_unix = time.time()
            self._append_activity_unlocked(u, action, detail)
            self._save_unlocked()

    def apply_metrics(
        self,
        chat_id: int,
        *,
        eid_delta: int = 0,
        pdf_delta: int = 0,
        fire_cooldown: bool = False,
    ) -> None:
        now = time.time()
        with self._lock:
            u = self._users.get(chat_id)
            if u is None:
                nu = UserMetrics(
                    chat_id=chat_id,
                    first_seen_unix=now,
                    last_seen_unix=now,
                    eid_retrievals=max(0, eid_delta),
                    pdf_downloads=max(0, pdf_delta),
                    last_success_unix=now if fire_cooldown else None,
                )
                self._users[chat_id] = nu
                u = nu
                if eid_delta > 0:
                    self._append_activity_unlocked(u, "eid", f"+{eid_delta} retrieval")
                if pdf_delta > 0:
                    self._append_activity_unlocked(u, "pdf", f"+{pdf_delta} download")
            else:
                u.eid_retrievals += max(0, eid_delta)
                u.pdf_downloads += max(0, pdf_delta)
                u.last_seen_unix = now
                if fire_cooldown:
                    u.last_success_unix = now
                if eid_delta > 0:
                    self._append_activity_unlocked(u, "eid", f"+{eid_delta} retrieval")
                if pdf_delta > 0:
                    self._append_activity_unlocked(u, "pdf", f"+{pdf_delta} download")
            self._save_unlocked()

    def broadcast_recipients(self) -> list[int]:
        with self._lock:
            return list(self._users.keys())

    def cooldown_remaining_seconds(self, chat_id: int, cooldown_seconds: int) -> int:
        if cooldown_seconds <= 0:
            return 0
        with self._lock:
            u = self._users.get(chat_id)
            if not u or u.last_success_unix is None:
                return 0
            elapsed = time.time() - u.last_success_unix
            left = cooldown_seconds - int(elapsed)
            return max(0, left)

    def summary(self) -> dict[str, Any]:
        with self._lock:
            users = list(self._users.values())
            total_users = len(users)
            total_pdf = sum(u.pdf_downloads for u in users)
            total_eid = sum(u.eid_retrievals for u in users)
            total_starts = sum(u.starts_count for u in users)
            top_pdf = sorted(users, key=lambda x: (-x.pdf_downloads, -x.last_seen_unix))[:15]
            return {
                "total_users": total_users,
                "total_pdf_downloads": total_pdf,
                "total_eid_retrievals": total_eid,
                "total_menu_starts": total_starts,
                "top_pdf_users": top_pdf,
            }

    def list_users_recent(self, *, limit: int = 200) -> list[UserMetrics]:
        with self._lock:
            users = list(self._users.values())
            users.sort(key=lambda x: -x.last_seen_unix)
            return users[:limit]

    def get_user_metrics(self, chat_id: int) -> UserMetrics | None:
        with self._lock:
            u = self._users.get(chat_id)
            return u

    def remove_user(self, chat_id: int) -> bool:
        with self._lock:
            if chat_id in self._users:
                del self._users[chat_id]
                self._save_unlocked()
                return True
            return False
