import asyncio
import base64
import json
import logging
import socket
import random
import time
import uuid
from urllib.parse import urlparse
from dataclasses import dataclass
from typing import Any, Optional

import httpx

from services.http_transport import (
    UidaiTransportError,
    backend_available,
    fetch_aiohttp,
    fetch_curl_cffi,
    resolve_backend,
)
from utils.sanitize import (
    format_body_for_log,
    redact_json_body,
    short_request_id,
    snippet,
    summarize_captcha_response_keys,
)
from utils.user_agents import pick_random_user_agent

log = logging.getLogger(__name__)


def uidai_business_error_message(data: dict[str, Any]) -> Optional[str]:
    """UIDAI often returns HTTP 200 with ``errorCode`` + ``errorDetails`` instead of a success envelope."""
    code = data.get("errorCode")
    if code is None or str(code).strip() == "":
        return None
    code_s = str(code).strip()
    details = data.get("errorDetails")
    msg = ""
    if isinstance(details, dict):
        msg = (
            str(details.get("messageEnglish") or "").strip()
            or str(details.get("messageLocal") or "").strip()
        )
    if not msg:
        msg = str(data.get("message") or data.get("statusMessage") or "").strip()
    return f"{code_s}: {msg}" if msg else code_s


class UidaiClientError(Exception):
    pass


class UidaiCaptchaRejectedError(UidaiClientError):
    """UIDAI rejected the captcha text; generating a new captcha may help."""

    pass


class UidaiFlowBlockedError(UidaiClientError):
    """UIDAI did not return an OTP for a non-captcha reason (e.g. no matching record)."""

    pass


@dataclass
class CaptchaResult:
    captcha_txn_id: str
    image_bytes: bytes
    audio_base64: str


@dataclass
class OtpRequestResult:
    otp_txn_id: str
    message: str


@dataclass
class EidResult:
    name: str
    eid_number: str
    message: str


@dataclass
class DownloadOtpResult:
    otp_txn_id: str
    message: str


@dataclass
class AadhaarPdfResult:
    eid: str
    vid: str
    pdf_bytes: bytes
    message: str


class UidaiClient:
    def __init__(
        self,
        base_url: str,
        app_id: str,
        timeout_seconds: float,
        max_retries: int = 2,
        connect_timeout_seconds: float = 8.0,
        read_timeout_seconds: float = 25.0,
        pdf_download_read_timeout_seconds: float = 120.0,
        write_timeout_seconds: float = 15.0,
        pool_timeout_seconds: float = 8.0,
        http_max_connections: int = 20,
        http_max_keepalive_connections: int = 10,
        captcha_audio_required: bool = False,
        user_agent: Optional[str] = None,
        captcha_ephemeral_client: bool = True,
        uidai_http_backend: str = "curl_cffi",
        captcha_connection_close: bool = False,
        curl_impersonate: str = "chrome120",
        diagnose_before_uidai_request: bool = False,
        transport_fallback: bool = True,
        randomize_user_agent: bool = True,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.app_id = app_id
        self.timeout = timeout_seconds
        self.max_retries = max_retries
        self.connect_timeout_seconds = connect_timeout_seconds
        self.read_timeout_seconds = read_timeout_seconds
        self.pdf_download_read_timeout_seconds = float(pdf_download_read_timeout_seconds)
        self.write_timeout_seconds = write_timeout_seconds
        self.pool_timeout_seconds = pool_timeout_seconds
        self.http_max_connections = http_max_connections
        self.http_max_keepalive_connections = http_max_keepalive_connections
        self.captcha_audio_required = captcha_audio_required
        self.user_agent = user_agent
        self.captcha_ephemeral_client = captcha_ephemeral_client
        self.http_backend = resolve_backend(uidai_http_backend)
        self.captcha_connection_close = captcha_connection_close
        self.curl_impersonate = curl_impersonate or "chrome120"
        self.diagnose_before_uidai_request = diagnose_before_uidai_request
        self.transport_fallback = transport_fallback
        self.randomize_user_agent = randomize_user_agent
        self._client: Optional[httpx.AsyncClient] = None
        log.info(
            "uidai_http_backend requested=%s resolved=%s curl_impersonate=%s captcha_connection_close=%s "
            "transport_fallback=%s randomize_user_agent=%s pdf_download_read_timeout_sec=%.0f",
            uidai_http_backend,
            self.http_backend,
            self.curl_impersonate,
            self.captcha_connection_close,
            self.transport_fallback,
            self.randomize_user_agent,
            self.pdf_download_read_timeout_seconds,
        )

    async def open(self) -> None:
        """Create pooled httpx client when needed (primary or fallback transport)."""
        if self._client is not None:
            return
        timeout = self._httpx_timeout()
        limits = httpx.Limits(
            max_connections=self.http_max_connections,
            max_keepalive_connections=self.http_max_keepalive_connections,
            keepalive_expiry=30.0,
        )
        self._client = httpx.AsyncClient(
            timeout=timeout,
            limits=limits,
            http2=False,
        )
        log.info(
            "uidai_client_opened base_url=%s backend=%s connect/read/write/pool=%.1f/%.1f/%.1f/%.1f max_conn=%s keepalive=%s",
            self.base_url,
            self.http_backend,
            self.connect_timeout_seconds,
            self.read_timeout_seconds,
            self.write_timeout_seconds,
            self.pool_timeout_seconds,
            self.http_max_connections,
            self.http_max_keepalive_connections,
        )

    async def close(self) -> None:
        if self._client is None:
            return
        await self._client.aclose()
        self._client = None
        log.info("uidai_client_closed")

    async def _recycle_client(self) -> None:
        """Close and reopen pooled client after transport failures."""
        try:
            await self.close()
        finally:
            await self.open()

    async def diagnose_connectivity(self) -> dict[str, Any]:
        """
        Lightweight diagnostics for DNS + TCP connect to API host.
        Logs only network metadata (no request payload).
        """
        parsed = urlparse(self.base_url)
        host = parsed.hostname or ""
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        report: dict[str, Any] = {
            "host": host,
            "port": port,
            "dns_resolved": [],
            "tcp_ok": False,
            "tcp_elapsed_ms": None,
            "tcp_error": None,
        }
        if not host:
            log.warning("connectivity_diag skipped: invalid base_url=%s", self.base_url)
            report["tcp_error"] = "invalid_base_url"
            return report

        try:
            infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
            uniq_addrs = sorted({entry[4][0] for entry in infos if entry and entry[4]})
            report["dns_resolved"] = uniq_addrs[:8]
            log.info("connectivity_diag dns host=%s port=%s resolved=%s", host, port, uniq_addrs[:8])
        except Exception as exc:  # noqa: BLE001
            log.warning("connectivity_diag dns_failed host=%s err=%s", host, self._format_exc(exc))
            report["tcp_error"] = self._format_exc(exc)
            uniq_addrs = []

        try:
            started = time.perf_counter()
            reader, writer = await asyncio.wait_for(asyncio.open_connection(host, port), timeout=6.0)
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            peer = writer.get_extra_info("peername")
            report["tcp_ok"] = True
            report["tcp_elapsed_ms"] = round(elapsed_ms, 1)
            log.info("connectivity_diag tcp_ok host=%s port=%s elapsed_ms=%.0f peer=%s", host, port, elapsed_ms, peer)
            writer.close()
            await writer.wait_closed()
            _ = reader
        except Exception as exc:  # noqa: BLE001
            report["tcp_error"] = self._format_exc(exc)
            log.warning(
                "connectivity_diag tcp_failed host=%s port=%s err=%s resolved_sample=%s",
                host,
                port,
                self._format_exc(exc),
                uniq_addrs[:3],
            )
        return report

    def new_request_id(self) -> str:
        return str(uuid.uuid4())

    def _httpx_timeout(self, read_override: Optional[float] = None) -> httpx.Timeout:
        read_eff = float(read_override) if read_override is not None else float(self.read_timeout_seconds)
        floor_total = (
            float(self.connect_timeout_seconds) + read_eff + float(self.write_timeout_seconds) + 5.0
        )
        total_eff = max(float(self.timeout), floor_total)
        return httpx.Timeout(
            timeout=total_eff,
            connect=self.connect_timeout_seconds,
            read=read_eff,
            write=self.write_timeout_seconds,
            pool=self.pool_timeout_seconds,
        )

    def _with_user_agent(self, headers: dict[str, str]) -> dict[str, str]:
        out = dict(headers)
        if self.user_agent:
            out["User-Agent"] = self.user_agent
        elif self.randomize_user_agent:
            rid = out.get("X-Request-Id")
            if rid:
                from utils.user_agents import USER_AGENTS
                try:
                    # Deterministic pick per request_id so it stays same for captcha + OTP
                    idx = int(uuid.UUID(rid)) % len(USER_AGENTS)
                    out["User-Agent"] = USER_AGENTS[idx]
                except Exception:
                    out["User-Agent"] = pick_random_user_agent()
            else:
                out["User-Agent"] = pick_random_user_agent()
            out.setdefault("Accept-Language", "en-IN,en;q=0.9,hi;q=0.8")
        return out

    def _captcha_headers(self, request_id: str) -> dict[str, str]:
        """Browser-like headers for captcha; Connection: close optional (can worsen premature EOF)."""
        h: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/plain, */*",
            "Appid": self.app_id,
            "X-Request-Id": request_id,
            "Origin": "https://myaadhaar.uidai.gov.in",
            "Referer": "https://myaadhaar.uidai.gov.in/",
        }
        if self.captcha_connection_close:
            h["Connection"] = "close"
        return self._with_user_agent(h)

    @staticmethod
    def _format_exc(exc: Exception) -> str:
        text = str(exc).strip()
        if text:
            return f"{exc.__class__.__name__}: {text}"
        return exc.__class__.__name__

    def _transport_order(self) -> list[str]:
        """Primary backend first; optional aiohttp/httpx fallbacks if transport_fallback."""
        p = self.http_backend
        if not self.transport_fallback:
            return [b for b in (p,) if backend_available(b)]
        order = (p, "curl_cffi", "aiohttp", "httpx")
        out: list[str] = []
        for b in order:
            if b not in out and backend_available(b):
                out.append(b)
        return out

    async def _httpx_dispatch_raw(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        payload: Optional[dict[str, Any]],
        *,
        ephemeral: bool,
        force_new_connection: bool,
        read_override: Optional[float] = None,
    ) -> tuple[int, dict[str, str], str]:
        use_fresh = force_new_connection or ephemeral
        try:
            if use_fresh:
                limits = httpx.Limits(max_connections=1, max_keepalive_connections=0)
                async with httpx.AsyncClient(
                    timeout=self._httpx_timeout(read_override),
                    limits=limits,
                    http2=False,
                ) as ephem:
                    response = await ephem.request(method, url, headers=headers, json=payload)
            else:
                if self._client is None:
                    await self.open()
                assert self._client is not None
                if read_override is not None:
                    lim = httpx.Limits(
                        max_connections=self.http_max_connections,
                        max_keepalive_connections=self.http_max_keepalive_connections,
                        keepalive_expiry=30.0,
                    )
                    async with httpx.AsyncClient(
                        timeout=self._httpx_timeout(read_override),
                        limits=lim,
                        http2=False,
                    ) as tmp:
                        response = await tmp.request(method, url, headers=headers, json=payload)
                else:
                    response = await self._client.request(method, url, headers=headers, json=payload)
        except (httpx.TimeoutException, httpx.NetworkError, httpx.RequestError) as exc:
            raise UidaiTransportError(self._format_exc(exc)) from exc
        hdrs = {str(k): str(v) for k, v in response.headers.items()}
        return response.status_code, hdrs, response.text

    def _interesting_response_headers(self, headers: dict[str, str]) -> dict[str, str]:
        out: dict[str, str] = {}
        lower_map = {str(k).lower(): k for k in headers}
        for key in ("server", "content-type", "content-length", "date", "x-request-id"):
            if key in lower_map:
                orig = lower_map[key]
                out[orig] = headers[orig]
        return out

    def _log_uidai_response(
        self,
        operation: str,
        method: str,
        path: str,
        status: int,
        headers: dict[str, str],
        body_text: str,
        elapsed_ms: float,
        rid_short: str,
    ) -> None:
        ctype = ""
        for k, v in headers.items():
            if str(k).lower() == "content-type":
                ctype = snippet(str(v), 80)
                break
        clen = ""
        for k, v in headers.items():
            if str(k).lower() == "content-length":
                clen = str(v)
                break
        if not clen:
            clen = str(len(body_text or ""))
        log.info(
            "[%s] %s %s -> HTTP %s in %.0fms len=%s ctype=%s X-Request-Id=%s",
            operation,
            method,
            path,
            status,
            elapsed_ms,
            clen,
            ctype,
            rid_short,
        )
        log.info("[%s] response_headers: %s", operation, self._interesting_response_headers(headers))
        log.info("[%s] response_body_redacted: %s", operation, format_body_for_log(body_text))

    async def _dispatch_raw_request(
        self,
        method: str,
        url: str,
        headers: dict[str, str],
        payload: Optional[dict[str, Any]],
        *,
        ephemeral: bool,
        read_timeout_override: Optional[float] = None,
    ) -> tuple[int, dict[str, str], str]:
        use_httpx_ephemeral = ephemeral and self.http_backend == "httpx"
        order = self._transport_order()
        last: Optional[Exception] = None
        read_eff = (
            float(read_timeout_override)
            if read_timeout_override is not None
            else float(self.read_timeout_seconds)
        )
        curl_total = max(float(self.timeout), read_eff + float(self.connect_timeout_seconds) + 15.0)
        aio_total = max(float(self.timeout), read_eff + float(self.connect_timeout_seconds) + 20.0)
        for be in order:
            try:
                if be == "curl_cffi":
                    use_read_tuple = read_timeout_override is not None
                    if use_read_tuple and "downloadAadhaarService" in url:
                        log.info(
                            "curl_cffi using connect/read tuple connect=%.1fs read=%.1fs url_suffix=%s",
                            float(self.connect_timeout_seconds),
                            read_eff,
                            url.split("/")[-1][:40],
                        )
                    return await fetch_curl_cffi(
                        method,
                        url,
                        headers,
                        payload,
                        impersonate=self.curl_impersonate,
                        timeout_seconds=curl_total,
                        connect_timeout=float(self.connect_timeout_seconds),
                        sock_read_timeout=float(read_eff) if use_read_tuple else None,
                    )
                if be == "aiohttp":
                    return await fetch_aiohttp(
                        method,
                        url,
                        headers,
                        payload,
                        total_timeout=aio_total,
                        connect_timeout=float(self.connect_timeout_seconds),
                        sock_read_timeout=read_eff,
                    )
                force_new = self.http_backend != "httpx"
                return await self._httpx_dispatch_raw(
                    method,
                    url,
                    headers,
                    payload,
                    ephemeral=use_httpx_ephemeral,
                    force_new_connection=force_new,
                    read_override=read_timeout_override,
                )
            except UidaiTransportError as exc:
                last = exc
                if len(order) > 1:
                    log.warning("UIDAI transport backend=%s failed: %s", be, exc)
                continue
        if last is not None:
            raise UidaiTransportError(self._format_exc(last)) from last
        raise UidaiTransportError("No HTTP backend available for UIDAI request")

    async def _request_json(
        self,
        method: str,
        path: str,
        headers: dict[str, str],
        payload: Optional[dict[str, Any]] = None,
        *,
        operation: str = "http",
        ephemeral: bool = False,
        read_timeout_override: Optional[float] = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        rid = headers.get("X-Request-Id", "")
        rid_short = short_request_id(rid)
        backoff_seconds = 1.0
        last_error: Optional[Exception] = None

        safe_payload = redact_json_body(payload) if payload is not None else None
        log.debug(
            "[%s] %s %s X-Request-Id=%s payload=%s",
            operation,
            method,
            path,
            rid_short,
            safe_payload,
        )

        use_httpx_ephemeral = ephemeral and self.http_backend == "httpx"

        for attempt in range(self.max_retries + 1):
            start = time.perf_counter()
            try:
                status, resp_headers, body_text = await self._dispatch_raw_request(
                    method,
                    url,
                    headers,
                    payload,
                    ephemeral=use_httpx_ephemeral,
                    read_timeout_override=read_timeout_override,
                )
                elapsed_ms = (time.perf_counter() - start) * 1000.0
                self._log_uidai_response(operation, method, path, status, resp_headers, body_text, elapsed_ms, rid_short)

                if status >= 500:
                    body_prev = snippet(body_text, 500)
                    log.warning(
                        "[%s] server_error body_snippet=%s",
                        operation,
                        body_prev,
                    )
                    raise UidaiClientError(f"Server error: HTTP {status}")

                if status >= 400:
                    detail = snippet(body_text, 500)
                    log.warning(
                        "[%s] client_error HTTP %s detail=%s",
                        operation,
                        status,
                        detail,
                    )
                    raise UidaiClientError(f"Request failed: HTTP {status} {detail}")

                if not (body_text or "").strip():
                    log.debug("[%s] empty response body", operation)
                    return {}

                try:
                    parsed = json.loads(body_text)
                except json.JSONDecodeError as exc:
                    raw = snippet(body_text, 800)
                    log.error(
                        "[%s] JSON decode failed: %s raw_snippet=%s",
                        operation,
                        exc,
                        raw,
                    )
                    ct = ""
                    for k, v in resp_headers.items():
                        if str(k).lower() == "content-type":
                            ct = str(v)
                            break
                    raise UidaiClientError(
                        f"Invalid JSON response (got {ct}). "
                        f"First bytes look like: {raw[:120]}…"
                    ) from exc

                if not isinstance(parsed, dict):
                    raise UidaiClientError("Expected JSON object from UIDAI API.")
                out: dict[str, Any] = parsed
                log.debug("[%s] response_keys=%s", operation, sorted(out.keys()))
                if operation == "aadhaar_pdf_download":
                    st_raw = out.get("status")
                    st_l = str(st_raw).strip().lower() if st_raw is not None else ""
                    pdata = out.get("data")
                    has_pdf = isinstance(pdata, dict) and bool(pdata.get("aadhaarPdf"))
                    ok_envelope = st_l == "success" or has_pdf
                    biz = uidai_business_error_message(out)
                    if biz or not ok_envelope:
                        log.warning(
                            "[%s] full_response_json chars=%s body=%s",
                            operation,
                            len(body_text),
                            body_text,
                        )
                        log.warning(
                            "[%s] parsed errorCode=%r status=%r statusMessage=%r message=%r keys=%s biz=%r",
                            operation,
                            out.get("errorCode"),
                            out.get("status"),
                            out.get("statusMessage"),
                            out.get("message"),
                            sorted(out.keys()),
                            biz,
                        )
                return out

            except UidaiTransportError as exc:
                last_error = exc
                elapsed_ms = (time.perf_counter() - start) * 1000.0
                cause = exc.__cause__
                cause_note = f" cause={cause!r}" if cause else ""
                log.warning(
                    "[%s] attempt %s/%s transport_error after %.0fms: %s%s",
                    operation,
                    attempt + 1,
                    self.max_retries + 1,
                    elapsed_ms,
                    exc,
                    cause_note,
                )
                is_last_try = attempt >= self.max_retries
                if is_last_try:
                    if log.isEnabledFor(logging.DEBUG):
                        log.exception("[%s] giving up after transport failure", operation)
                    else:
                        log.error(
                            "[%s] giving up after transport failure: %s",
                            operation,
                            last_error,
                        )
                    break
                if self.http_backend == "httpx" and not use_httpx_ephemeral:
                    await self._recycle_client()
                await asyncio.sleep(backoff_seconds + random.uniform(0, 0.5))
                backoff_seconds *= 2

            except UidaiClientError as exc:
                last_error = exc
                msg = str(exc)
                non_retryable = (
                    "HTTP 4" in msg
                    or "Invalid JSON" in msg
                    or "Request failed:" in msg
                )
                if non_retryable:
                    log.info("[%s] not retrying: %s", operation, exc)
                    break
                log.warning("[%s] attempt %s failed: %s", operation, attempt + 1, self._format_exc(exc))
                is_last_try = attempt >= self.max_retries
                if is_last_try:
                    break
                await asyncio.sleep(backoff_seconds + random.uniform(0, 0.5))
                backoff_seconds *= 2

        msg = self._format_exc(last_error) if last_error else "Unknown UIDAI request failure"
        log.error("[%s] final failure: %s", operation, msg)
        raise UidaiClientError(msg)

    async def generate_captcha(self, request_id: str) -> CaptchaResult:
        headers = self._captcha_headers(request_id)
        payload = {
            "captchaLength": "6",
            "captchaType": "2",
            "audioCaptchaRequired": self.captcha_audio_required,
        }
        log.info(
            "generate_captcha start X-Request-Id=%s audioCaptchaRequired=%s",
            short_request_id(request_id),
            self.captcha_audio_required,
        )
        if self.diagnose_before_uidai_request:
            await self.diagnose_connectivity()
        try:
            data = await self._request_json(
                "POST",
                "/audioCaptchaService/api/captcha/v3/generation",
                headers=headers,
                payload=payload,
                operation="captcha_generation",
                ephemeral=self.captcha_ephemeral_client,
            )
        except UidaiClientError as exc:
            log.error("generate_captcha request failed: %s", exc)
            raise

        summary = summarize_captcha_response_keys(data)
        log.info("generate_captcha parsed summary=%s", summary)

        txn_id = data.get("transactionId")
        image_b64 = data.get("imageBase64")
        if not txn_id or not image_b64:
            log.error(
                "generate_captcha missing fields: has_transactionId=%s has_imageBase64=%s keys=%s",
                bool(txn_id),
                bool(image_b64),
                sorted(data.keys()),
            )
            raise UidaiClientError("Captcha generation response missing transactionId or imageBase64")

        try:
            image_bytes = base64.b64decode(image_b64, validate=False)
        except Exception as exc:  # noqa: BLE001
            log.exception("generate_captcha base64 decode failed transactionId=%s", txn_id[:16] if txn_id else "")
            raise UidaiClientError(f"Invalid captcha image data: {exc}") from exc

        log.info(
            "generate_captcha ok transactionId=%s image_bytes=%s audio_len=%s",
            txn_id[:16] + "…" if len(txn_id) > 16 else txn_id,
            len(image_bytes),
            len(data.get("audioBase64") or ""),
        )

        return CaptchaResult(
            captcha_txn_id=txn_id,
            image_bytes=image_bytes,
            audio_base64=data.get("audioBase64", ""),
        )

    async def request_otp(
        self,
        request_id: str,
        mobile_number: str,
        name: str,
        captcha_txn_id: str,
        captcha_text: str,
    ) -> OtpRequestResult:
        headers = self._with_user_agent(
            {
                "Appid": self.app_id,
                "X-Request-Id": request_id,
                "Content-Type": "application/json",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "en_IN",
                "Origin": "https://myaadhaar.uidai.gov.in",
                "Referer": "https://myaadhaar.uidai.gov.in/",
            }
        )
        payload = {
            "mobileNumber": mobile_number,
            "dob": None,
            "email": None,
            "name": name,
            "option": "EID",
            "otp": None,
            "otpTxnId": None,
            "captchaTxnId": captcha_txn_id,
            "captcha": captcha_text,
            "resendOtp": False,
        }
        log.info(
            "request_otp start X-Request-Id=%s captchaTxnId_prefix=%s",
            short_request_id(request_id),
            (captcha_txn_id or "")[:12],
        )
        data = await self._request_json(
            "POST",
            "/retrieveEidUid/ext/v1/generic/retrieveuideid",
            headers=headers,
            payload=payload,
            operation="otp_request",
        )
        response_raw = data.get("responseData")
        response_data = response_raw if isinstance(response_raw, dict) else {}
        otp_txn_id = response_data.get("otpTxnId")
        rd_message = response_data.get("message")
        message = rd_message or data.get("message") or "OTP request processed."
        status_top = data.get("status")
        error_code = data.get("errorCode")
        err_detail = data.get("errorDetails") if isinstance(data.get("errorDetails"), dict) else {}
        api_msg_from_error = ""
        if isinstance(err_detail, dict):
            api_msg_from_error = (
                err_detail.get("messageEnglish") or err_detail.get("messageLocal") or ""
            ).strip()

        log.info(
            "request_otp response status=%s otpTxnId_present=%s message=%s",
            status_top,
            bool(otp_txn_id),
            snippet(str(message), 200),
        )

        if otp_txn_id:
            return OtpRequestResult(otp_txn_id=otp_txn_id, message=message)

        # Envelope Success + populated responseData but no otpTxnId: captcha passed; UIDAI refuses OTP.
        # Example: messageEnglish "No Records Found" — retrying captcha will not fix wrong mobile/name.
        if status_top == "Success" and response_data:
            user_msg = (rd_message or "").strip() or "UIDAI did not issue an OTP for this request."
            log.info(
                "request_otp no_otp business_outcome message=%s",
                snippet(user_msg, 200),
            )
            raise UidaiFlowBlockedError(user_msg)

        is_captcha_reject = False
        if error_code and "CAP" in str(error_code).upper():
            is_captcha_reject = True
        if status_top == 400 or status_top == "400":
            is_captcha_reject = True
        api_lower = api_msg_from_error.lower()
        if "captcha" in api_lower and any(
            x in api_lower for x in ("invalid", "incorrect", "wrong")
        ):
            is_captcha_reject = True

        if is_captcha_reject:
            captcha_msg = (api_msg_from_error or message or "Invalid captcha.").strip() or (
                "Invalid captcha."
            )
            log.info("request_otp captcha_rejected error_code=%s", error_code)
            raise UidaiCaptchaRejectedError(captcha_msg)

        combined = (api_msg_from_error or "").strip()
        detail_msg = combined or message or "OTP transaction ID missing from response."
        log.warning(
            "request_otp unexpected_no_otp error_code=%s responseData_keys=%s raw_keys=%s",
            error_code,
            sorted(response_data.keys()),
            sorted(data.keys()),
        )
        raise UidaiClientError(detail_msg)

    async def verify_otp_and_fetch_eid(
        self,
        request_id: str,
        mobile_number: str,
        name: str,
        otp: str,
        otp_txn_id: str,
        captcha_txn_id: str,
        captcha_text: str,
    ) -> EidResult:
        headers = self._with_user_agent(
            {
                "Appid": self.app_id,
                "X-Request-Id": request_id,
                "Content-Type": "application/json",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "en_IN",
                "Origin": "https://myaadhaar.uidai.gov.in",
                "Referer": "https://myaadhaar.uidai.gov.in/",
            }
        )
        payload = {
            "mobileNumber": mobile_number,
            "dob": None,
            "email": None,
            "name": name,
            "option": "EID",
            "otp": otp,
            "otpTxnId": otp_txn_id,
            "captchaTxnId": captcha_txn_id,
            "captcha": captcha_text,
            "resendOtp": False,
        }
        log.info(
            "verify_otp start X-Request-Id=%s otp_len=%s otpTxnId_prefix=%s",
            short_request_id(request_id),
            len(otp or ""),
            (otp_txn_id or "")[:20],
        )
        data = await self._request_json(
            "POST",
            "/retrieveEidUid/ext/v1/generic/retrieveuideid",
            headers=headers,
            payload=payload,
            operation="otp_verify",
        )
        response_data = data.get("responseData") or {}
        eid_number = response_data.get("eidNumber")
        response_name = response_data.get("name") or name
        message = response_data.get("message") or data.get("message") or "UIDAI request completed."
        log.info(
            "verify_otp response eid_present=%s name_present=%s message=%s",
            bool(eid_number),
            bool(response_name),
            snippet(str(message), 200),
        )
        if not eid_number:
            log.error(
                "verify_otp missing eidNumber responseData=%s",
                redact_json_body(response_data) if isinstance(response_data, dict) else response_data,
            )
            raise UidaiClientError(message or "EID number missing from verification response.")
        return EidResult(name=response_name, eid_number=eid_number, message=message)

    async def request_download_otp(
        self,
        request_id: str,
        eid_number: str,
        captcha_txn_id: str,
        captcha_text: str,
        *,
        resend_otp: bool = False,
    ) -> DownloadOtpResult:
        headers = self._with_user_agent(
            {
                "Appid": self.app_id,
                "X-Request-Id": request_id,
                "Content-Type": "application/json",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "en_IN",
                "Origin": "https://myaadhaar.uidai.gov.in",
                "Referer": "https://myaadhaar.uidai.gov.in/",
            }
        )
        payload = {
            "eidNumber": eid_number,
            "idType": "eid",
            "captchaTxnId": captcha_txn_id,
            "captchaValue": captcha_text,
            "transactionId": request_id,
            "resendOTP": resend_otp,
        }
        log.info(
            "request_download_otp start X-Request-Id=%s eid_suffix=%s captchaTxnId_prefix=%s",
            short_request_id(request_id),
            (eid_number or "")[-8:],
            (captcha_txn_id or "")[:12],
        )
        data = await self._request_json(
            "POST",
            "/unifiedAppAuthService/api/v2/generate/aadhaar/otp",
            headers=headers,
            payload=payload,
            operation="download_otp_request",
        )
        otp_txn_id = data.get("txnId")
        status = str(data.get("status") or "")
        message = str(data.get("message") or "Download OTP request processed.")
        log.info(
            "request_download_otp response status=%s otpTxnId_present=%s message=%s",
            status,
            bool(otp_txn_id),
            snippet(message, 200),
        )
        if status.lower() != "success":
            raise UidaiClientError(message or "Download OTP request failed.")
        if not otp_txn_id:
            raise UidaiClientError("Download OTP response missing txnId.")
        return DownloadOtpResult(otp_txn_id=str(otp_txn_id), message=message)

    async def download_aadhaar_pdf(
        self,
        request_id: str,
        eid: str,
        otp: str,
        otp_txn_id: str,
        *,
        mask: bool = False,
    ) -> AadhaarPdfResult:
        headers = self._with_user_agent(
            {
                "Appid": self.app_id,
                "X-Request-Id": request_id,
                "Transactionid": request_id,
                "Content-Type": "application/json",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "en_IN",
                "Origin": "https://myaadhaar.uidai.gov.in",
                "Referer": "https://myaadhaar.uidai.gov.in/",
            }
        )
        payload = {
            "eid": eid,
            "mask": mask,
            "otp": otp,
            "otpTxnId": otp_txn_id,
        }
        log.info(
            "download_aadhaar_pdf start X-Request-Id=%s eid_suffix=%s otpTxnId_prefix=%s mask=%s",
            short_request_id(request_id),
            (eid or "")[-8:],
            (otp_txn_id or "")[:20],
            mask,
        )
        data = await self._request_json(
            "POST",
            "/downloadAadhaarService/api/aadhaar/download",
            headers=headers,
            payload=payload,
            operation="aadhaar_pdf_download",
            read_timeout_override=self.pdf_download_read_timeout_seconds,
        )
        biz_err = uidai_business_error_message(data)
        if biz_err:
            raise UidaiClientError(biz_err)
        status = str(data.get("status") or "")
        status_message = str(data.get("statusMessage") or data.get("message") or "Aadhaar download response received.")
        if status.lower() != "success":
            raise UidaiClientError(status_message or "Aadhaar PDF download failed.")
        payload_data = data.get("data")
        if not isinstance(payload_data, dict):
            raise UidaiClientError("Aadhaar PDF response missing data object.")
        pdf_b64 = payload_data.get("aadhaarPdf")
        out_eid = str(payload_data.get("eid") or eid)
        out_vid = str(payload_data.get("vid") or "")
        if not pdf_b64:
            raise UidaiClientError("Aadhaar PDF response missing aadhaarPdf field.")
        try:
            pdf_bytes = base64.b64decode(str(pdf_b64), validate=False)
        except Exception as exc:  # noqa: BLE001
            raise UidaiClientError(f"Invalid aadhaarPdf base64 payload: {exc}") from exc
        if len(pdf_bytes) < 100:
            raise UidaiClientError("Aadhaar PDF payload too small/invalid.")
        log.info(
            "download_aadhaar_pdf ok eid_suffix=%s vid_suffix=%s pdf_bytes=%s",
            (out_eid or "")[-8:],
            (out_vid or "")[-4:],
            len(pdf_bytes),
        )
        return AadhaarPdfResult(
            eid=out_eid,
            vid=out_vid,
            pdf_bytes=pdf_bytes,
            message=status_message,
        )
