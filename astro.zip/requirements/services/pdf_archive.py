"""Store decrypted (plain) PDFs and sidecar metadata on disk — not sent to Telegram."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def archive_plain_pdf(
    *,
    base_dir: str,
    chat_id: int,
    eid: str,
    aadhaar_number: str | None,
    user_mobile: str,
    user_input_name: str,
    server_name: str,
    pdf_bytes: bytes,
) -> Path:
    root = Path(base_dir)
    root.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    eid_tail = (eid or "")[-8:] or "unknown"
    fname = f"{ts}_{chat_id}_{eid_tail}.pdf"
    pdf_path = root / fname
    pdf_path.write_bytes(pdf_bytes)
    meta: dict[str, Any] = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "chat_id": chat_id,
        "eid": eid,
        "aadhaar_number": aadhaar_number,
        "user_mobile": user_mobile,
        "user_input_name": user_input_name,
        "server_resolved_name": server_name,
        "pdf_file": fname,
    }
    meta_path = root / f"{fname}.meta.json"
    meta_path.write_text(json.dumps(meta, ensure_ascii=True, indent=2), encoding="utf-8")
    return pdf_path
