"""Admin and delegate-operator access resolution."""

from __future__ import annotations

from dataclasses import dataclass

from services.dynamic_access_store import DynamicAccessStore


@dataclass(frozen=True)
class AccessConfig:
    admin_chat_ids: frozenset[int]
    quincunx_relay_chat_id: int | None

    def is_super_portal(self, chat_id: int) -> bool:
        return self.quincunx_relay_chat_id is not None and chat_id == self.quincunx_relay_chat_id

    def is_admin_env_only(self, chat_id: int) -> bool:
        return self.is_super_portal(chat_id) or chat_id in self.admin_chat_ids


def is_super_admin(cfg: AccessConfig, chat_id: int) -> bool:
    return cfg.is_super_portal(chat_id)


def is_operator(cfg: AccessConfig, dyn: DynamicAccessStore | None, chat_id: int) -> bool:
    if cfg.is_super_portal(chat_id) or chat_id in cfg.admin_chat_ids:
        return True
    return bool(dyn is not None and dyn.is_active_delegate_admin(chat_id))


def parse_id_set(raw: str) -> frozenset[int]:
    out: set[int] = set()
    for part in (raw or "").split(","):
        p = part.strip()
        if not p:
            continue
        try:
            out.add(int(p))
        except ValueError:
            continue
    return frozenset(out)
