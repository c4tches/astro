"""Local UIDAI captcha OCR via Tesseract (optional; requires Tesseract binary on PATH or TESSERACT_CMD)."""

from __future__ import annotations

import asyncio
import io
import logging
import math
import re
from collections import Counter

from PIL import Image, ImageFilter, ImageOps

log = logging.getLogger(__name__)

_TESSERACT_IMPORT_ERROR: Exception | None = None
try:
    import pytesseract
except Exception as exc:  # noqa: BLE001
    pytesseract = None  # type: ignore[misc, assignment]
    _TESSERACT_IMPORT_ERROR = exc


def _configure_tesseract(tesseract_cmd: str | None) -> bool:
    if pytesseract is None:
        log.warning(
            "captcha_ocr_unavailable import_error=%s",
            _TESSERACT_IMPORT_ERROR,
        )
        return False
    if tesseract_cmd and tesseract_cmd.strip():
        pytesseract.pytesseract.tesseract_cmd = tesseract_cmd.strip()
    return True


def _binarize(img: Image.Image, threshold: int) -> Image.Image:
    return img.point(lambda p, t=threshold: 255 if p > t else 0, mode="1").convert("L")


def _preprocess_variants_fast(im: Image.Image) -> list[Image.Image]:
    """Smaller variant set when Gemini is primary — speeds Tesseract fallback only."""
    gray = ImageOps.grayscale(im)
    w, h = gray.size
    nw = max(int(w * 3.0), 160)
    nh = max(int(h * 3.0), 56)
    scaled = gray.resize((nw, nh), Image.Resampling.LANCZOS)
    v = ImageOps.autocontrast(scaled)
    return [v, _binarize(v, 140), ImageOps.invert(v)]


def _preprocess_variants(im: Image.Image) -> list[Image.Image]:
    """UIDAI-friendly transforms — kept small so auto-solve stays reasonably fast."""
    gray = ImageOps.grayscale(im)
    bases: list[Image.Image] = []
    for scale_mul in (3.0, 4.0):
        w, h = gray.size
        nw = max(int(w * scale_mul), 160)
        nh = max(int(h * scale_mul), 56)
        scaled = gray.resize((nw, nh), Image.Resampling.LANCZOS)
        bases.append(ImageOps.autocontrast(scaled))
        bases.append(ImageOps.autocontrast(scaled.filter(ImageFilter.SHARPEN)))

    final: list[Image.Image] = []
    for v in bases:
        final.append(v)
        final.append(_binarize(v, 140))
        inv = ImageOps.invert(v)
        final.append(inv)
    return final


_ALNUM_6 = re.compile(r"^[A-Za-z0-9]{6}$")


def _pick_six_chars(text: str) -> str | None:
    cleaned = "".join(c for c in (text or "") if c.isalnum())
    if _ALNUM_6.fullmatch(cleaned):
        return cleaned
    return None


def _safe_conf(raw: object) -> float:
    try:
        x = float(raw)
    except (TypeError, ValueError):
        return -1.0
    if math.isnan(x):
        return -1.0
    return x


def solve_uidai_captcha_sync(
    image_bytes: bytes,
    *,
    tesseract_cmd: str | None = None,
    min_word_confidence: float = 52.0,
    consensus_min_confidence: float = 35.0,
    consensus_min_votes: int = 2,
    fast: bool = False,
) -> str | None:
    """
    Best-effort read of a 6-character alphanumeric UIDAI captcha.

    Uses (1) highest-confidence word read above ``min_word_confidence``, else
    (2) same 6-char string seen from ``consensus_min_votes`` independent reads
    each at least ``consensus_min_confidence``.

    Avoids sending garbage to UIDAI when Tesseract confidence is very low (was the main failure mode).
    """
    if not _configure_tesseract(tesseract_cmd):
        return None

    assert pytesseract is not None

    try:
        im = Image.open(io.BytesIO(image_bytes))
        im.load()
    except Exception as exc:
        log.warning("captcha_ocr_open_failed err=%s", exc)
        return None

    best_guess: str | None = None
    best_conf = -1.0
    consensus_counter: Counter[str] = Counter()

    if fast:
        variants = _preprocess_variants_fast(im)
        whitelist_modes = ("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",)
        psm_modes = ("8",)
    else:
        variants = _preprocess_variants(im)
        # Mixed-case then uppercase-only (many UIDAI CAPTCHAs render uppercase-heavy).
        whitelist_modes = (
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        )
        psm_modes = ("8", "13")

    for variant in variants:
        for wl in whitelist_modes:
            for psm in psm_modes:
                config = f"--oem 3 --psm {psm} -c tessedit_char_whitelist={wl}"
                try:
                    data = pytesseract.image_to_data(
                        variant,
                        config=config,
                        output_type=pytesseract.Output.DICT,
                    )
                except Exception as exc:
                    log.debug("captcha_ocr_tesseract_fail psm=%s err=%s", psm, exc)
                    continue

                texts = data.get("text") or []
                confs = data.get("conf") or []
                n = len(texts)

                local_best_conf = -1.0
                local_best_guess: str | None = None
                for i in range(n):
                    raw = (texts[i] or "").strip()
                    conf = _safe_conf(confs[i] if i < len(confs) else -1)
                    guess = _pick_six_chars(raw)
                    if not guess:
                        continue
                    if conf >= min_word_confidence and conf > best_conf:
                        best_conf = conf
                        best_guess = guess
                    if conf > local_best_conf:
                        local_best_conf = conf
                        local_best_guess = guess

                if (
                    local_best_guess
                    and local_best_conf >= consensus_min_confidence
                    and _ALNUM_6.fullmatch(local_best_guess)
                ):
                    consensus_counter[local_best_guess] += 1

    if best_guess:
        log.info("captcha_ocr_accept_high_conf conf=%.1f", best_conf)
        return best_guess

    if consensus_counter:
        guess, votes = consensus_counter.most_common(1)[0]
        if votes >= consensus_min_votes and _ALNUM_6.fullmatch(guess):
            log.info(
                "captcha_ocr_accept_consensus votes=%s min_conf_floor=%s",
                votes,
                consensus_min_confidence,
            )
            return guess

    log.info(
        "captcha_ocr_no_acceptable_read best_high_conf=%.1f min_required=%s consensus_keys=%s",
        best_conf,
        min_word_confidence,
        len(consensus_counter),
    )
    return None


async def solve_uidai_captcha_async(
    image_bytes: bytes,
    *,
    tesseract_cmd: str | None = None,
    min_word_confidence: float = 52.0,
    consensus_min_confidence: float = 35.0,
    consensus_min_votes: int = 2,
    fast: bool = False,
) -> str | None:
    return await asyncio.to_thread(
        solve_uidai_captcha_sync,
        image_bytes,
        tesseract_cmd=tesseract_cmd,
        min_word_confidence=min_word_confidence,
        consensus_min_confidence=consensus_min_confidence,
        consensus_min_votes=consensus_min_votes,
        fast=fast,
    )


async def solve_uidai_captcha_pipeline_async(
    image_bytes: bytes,
    *,
    gemini_api_key: str | None,
    gemini_models: tuple[str, ...],
    gemini_timeout_seconds: float,
    tesseract_cmd: str | None,
    min_word_confidence: float,
    consensus_min_confidence: float,
    consensus_min_votes: int,
    gemini_parallel: bool = True,
    gemini_parallel_max: int = 3,
) -> str | None:
    """Try Gemini Vision first when ``GEMINI_API_KEY`` is set, then local Tesseract."""
    key = (gemini_api_key or "").strip()
    tess_fast = bool(key)
    if key:
        from services.captcha_gemini_solver import (
            solve_uidai_captcha_gemini_race_models_async,
            solve_uidai_captcha_gemini_try_models_async,
        )

        use_race = bool(
            gemini_parallel
            and len([m for m in gemini_models if m and str(m).strip()]) > 1
            and int(gemini_parallel_max) >= 2
        )
        if use_race:
            g = await solve_uidai_captcha_gemini_race_models_async(
                image_bytes,
                api_key=key,
                models=gemini_models,
                timeout_seconds=gemini_timeout_seconds,
                parallel_max=gemini_parallel_max,
            )
        else:
            g = await solve_uidai_captcha_gemini_try_models_async(
                image_bytes,
                api_key=key,
                models=gemini_models,
                timeout_seconds=gemini_timeout_seconds,
            )
        if g:
            return g

    return await solve_uidai_captcha_async(
        image_bytes,
        tesseract_cmd=tesseract_cmd,
        min_word_confidence=min_word_confidence,
        consensus_min_confidence=consensus_min_confidence,
        consensus_min_votes=consensus_min_votes,
        fast=tess_fast,
    )


def check_tesseract_available(tesseract_cmd: str | None) -> tuple[bool, str]:
    """Returns (ok, detail) for startup diagnostics when CAPTCHA_AUTO_SOLVE is enabled."""
    if not _configure_tesseract(tesseract_cmd):
        return False, "pytesseract not installed"
    assert pytesseract is not None
    try:
        ver = pytesseract.get_tesseract_version()
        return True, str(ver)
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
