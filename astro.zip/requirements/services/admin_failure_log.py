"""Append-only JSONL log of user-visible flow failures for operators (/panel)."""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from datetime import datetime, timezone

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class FailureRecord:
    ts: str
    kind: str
    chat_id: int
    username: str | None
    detail: str


class AdminFailureLog:
    """Stores recent failure lines; operators browse via admin panel."""

    def __init__(self, path: str, *, max_file_lines: int = 4000) -> None:
        self.path = path
        self.max_file_lines = max(500, max_file_lines)

    def append(
        self,
        *,
        kind: str,
        chat_id: int,
        username: str | None,
        detail: str,
    ) -> None:
        ts = datetime.now(timezone.utc).isoformat()
        rec = {
            "ts": ts,
            "kind": (kind or "unknown")[:120],
            "chat_id": int(chat_id),
            "username": (username or "")[:64] or None,
            "detail": (detail or "").replace("\n", " ").strip()[:800],
        }
        try:
            parent = os.path.dirname(self.path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            self._trim_if_needed()
        except Exception:
            log.exception("admin_failure_log_append_failed path=%s", self.path)

    def _trim_if_needed(self) -> None:
        try:
            if not os.path.isfile(self.path):
                return
            with open(self.path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) <= self.max_file_lines:
                return
            keep = lines[-self.max_file_lines :]
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.writelines(keep)
            os.replace(tmp, self.path)
        except Exception:
            log.exception("admin_failure_log_trim_failed")

    def read_newest(self, *, limit: int = 200) -> list[FailureRecord]:
        limit = max(1, min(500, limit))
        if not os.path.isfile(self.path):
            return []
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                lines = f.readlines()[-limit:]
        except OSError:
            return []
        out: list[FailureRecord] = []
        for line in reversed(lines):
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                out.append(
                    FailureRecord(
                        ts=str(d.get("ts") or ""),
                        kind=str(d.get("kind") or ""),
                        chat_id=int(d.get("chat_id") or 0),
                        username=d.get("username"),
                        detail=str(d.get("detail") or ""),
                    )
                )
            except (json.JSONDecodeError, TypeError, ValueError):
                continue
        return out
