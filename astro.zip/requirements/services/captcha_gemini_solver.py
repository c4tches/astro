"""Gemini Vision reads UIDAI CAPTCHA images (optional; requires GEMINI_API_KEY)."""

from __future__ import annotations

import asyncio
import io
import logging
import re
from collections.abc import Sequence

from PIL import Image

from utils.validators import validate_uidai_captcha_strict

log = logging.getLogger(__name__)

_GENAI_IMPORT_ERROR: Exception | None = None
try:
    import google.generativeai as genai  # type: ignore[import-untyped]
except Exception as exc:  # noqa: BLE001
    genai = None  # type: ignore[misc, assignment]
    _GENAI_IMPORT_ERROR = exc


_PROMPT = """This image is a distorted CAPTCHA showing exactly 6 characters.
Characters are letters (A-Z or a-z) and/or digits (0-9).
Read the CAPTCHA exactly as shown (preserve letter case).
Reply with ONLY those 6 characters — no spaces, quotes, markdown, or explanation."""

_INLINE_SIX = re.compile(r"[A-Za-z0-9]{6}")


def _pick_from_response_text(raw: str | None) -> str | None:
    if not raw:
        return None
    stripped = raw.strip()
    ok, text = validate_uidai_captcha_strict(stripped)
    if ok:
        return text
    compact = "".join(c for c in stripped if c.isalnum())
    ok2, text2 = validate_uidai_captcha_strict(compact)
    if ok2:
        return text2
    m = _INLINE_SIX.search(compact)
    if m:
        ok3, text3 = validate_uidai_captcha_strict(m.group(0))
        if ok3:
            return text3
    return None


def solve_uidai_captcha_gemini_sync(
    image_bytes: bytes,
    *,
    api_key: str,
    model: str,
) -> str | None:
    if genai is None:
        log.warning("captcha_gemini_unavailable import_error=%s", _GENAI_IMPORT_ERROR)
        return None

    api_key = api_key.strip()
    if not api_key:
        return None

    try:
        img = Image.open(io.BytesIO(image_bytes))
        img.load()
        if img.mode not in ("RGB", "RGBA"):
            img = img.convert("RGB")
    except Exception as exc:
        log.warning("captcha_gemini_image_open_failed err=%s", exc)
        return None

    genai.configure(api_key=api_key)
    gm = genai.GenerativeModel(model)

    try:
        cfg = genai.types.GenerationConfig(max_output_tokens=32, temperature=0.05)
    except AttributeError:
        cfg = {"max_output_tokens": 32, "temperature": 0.05}

    try:
        resp = gm.generate_content([_PROMPT, img], generation_config=cfg)
    except Exception as exc:
        msg = str(exc).lower()
        if "429" in msg or "quota" in msg or "resource exhausted" in msg:
            log.warning(
                "captcha_gemini_quota_or_limit model=%s (try another model in GEMINI_CAPTCHA_MODELS or enable billing)",
                model,
            )
        else:
            log.warning("captcha_gemini_request_failed model=%s err=%s", model, exc)
        return None

    try:
        raw_text = (resp.text or "").strip()
    except ValueError:
        log.warning("captcha_gemini_blocked_or_empty candidates=%s", getattr(resp, "candidates", None))
        return None

    guess = _pick_from_response_text(raw_text)
    if guess:
        log.info("captcha_gemini_ok model=%s", model)
        return guess

    log.info("captcha_gemini_no_parseable_six preview=%s", repr(raw_text[:80]))
    return None


async def solve_uidai_captcha_gemini_async(
    image_bytes: bytes,
    *,
    api_key: str,
    model: str,
    timeout_seconds: float = 22.0,
) -> str | None:
    # Per-model ceiling: respect low timeouts for fast UX (floor avoids stuck threads).
    per_cap = max(3.0, min(float(timeout_seconds), 60.0))
    try:
        return await asyncio.wait_for(
            asyncio.to_thread(
                solve_uidai_captcha_gemini_sync,
                image_bytes,
                api_key=api_key,
                model=model,
            ),
            timeout=per_cap,
        )
    except asyncio.TimeoutError:
        log.warning("captcha_gemini_timeout model=%s cap_sec=%s", model, per_cap)
        return None


async def solve_uidai_captcha_gemini_race_models_async(
    image_bytes: bytes,
    *,
    api_key: str,
    models: Sequence[str],
    timeout_seconds: float,
    parallel_max: int = 3,
) -> str | None:
    """Query several Gemini models concurrently; return the first parseable 6-char read."""
    models_clean = [m.strip() for m in models if m and str(m).strip()]
    if not models_clean:
        return None
    cap = max(1, min(int(parallel_max), 6, len(models_clean)))
    to_run = models_clean[:cap]
    if len(to_run) == 1:
        return await solve_uidai_captcha_gemini_async(
            image_bytes,
            api_key=api_key,
            model=to_run[0],
            timeout_seconds=timeout_seconds,
        )

    pending: set[asyncio.Task[str | None]] = {
        asyncio.create_task(
            solve_uidai_captcha_gemini_async(
                image_bytes,
                api_key=api_key,
                model=m,
                timeout_seconds=timeout_seconds,
            ),
        )
        for m in to_run
    }
    try:
        while pending:
            done, pending = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
            for finished in done:
                try:
                    result = finished.result()
                except asyncio.CancelledError:
                    result = None
                except Exception as exc:  # noqa: BLE001
                    log.debug("captcha_gemini_race_task_err err=%s", exc)
                    result = None
                if result:
                    for p in pending:
                        p.cancel()
                    if pending:
                        await asyncio.gather(*pending, return_exceptions=True)
                    log.info("captcha_gemini_race_ok tasks=%s", len(to_run))
                    return result
        return None
    finally:
        leftover = [t for t in pending if not t.done()]
        for t in leftover:
            t.cancel()
        if leftover:
            await asyncio.gather(*leftover, return_exceptions=True)


async def solve_uidai_captcha_gemini_try_models_async(
    image_bytes: bytes,
    *,
    api_key: str,
    models: Sequence[str],
    timeout_seconds: float = 22.0,
) -> str | None:
    """Try each model until one returns a valid 6-char read (handles per-model free-tier quotas)."""
    for model in models:
        m = (model or "").strip()
        if not m:
            continue
        result = await solve_uidai_captcha_gemini_async(
            image_bytes,
            api_key=api_key,
            model=m,
            timeout_seconds=timeout_seconds,
        )
        if result:
            return result
    return None


def gemini_sdk_available() -> bool:
    return genai is not None
