import json
from datetime import datetime, timezone

from utils.validators import mask_mobile


class ResultStore:
    def __init__(self, file_path: str) -> None:
        self.file_path = file_path

    def append_success(self, mobile_number: str, requested_name: str, resolved_name: str, eid_number: str) -> None:
        record = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "mobile_masked": mask_mobile(mobile_number),
            "requested_name": requested_name,
            "resolved_name": resolved_name,
            "eid_number": eid_number,
        }
        with open(self.file_path, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(record, ensure_ascii=True) + "\n")
