"""
Alternate HTTP stacks for UIDAI: curl_cffi (optional browser TLS presets), aiohttp, httpx.

curl_cffi: tries plain libcurl TLS first (impersonate=None), then versioned Chrome/Safari/Firefox
presets. Many Windows installs lack newer impersonation bundles — plain TLS often works.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

log = logging.getLogger(__name__)


class UidaiTransportError(Exception):
    """Raised when the HTTP layer fails before a complete response is parsed."""


try:
    from curl_cffi.requests import AsyncSession as CurlAsyncSession

    _CURL_CFFI = True
except ImportError:
    CurlAsyncSession = None  # type: ignore[misc, assignment]
    _CURL_CFFI = False

try:
    import aiohttp

    _AIOHTTP = True
except ImportError:
    aiohttp = None  # type: ignore[assignment]
    _AIOHTTP = False


def backend_available(name: str) -> bool:
    n = (name or "").strip().lower()
    if n == "curl_cffi":
        return _CURL_CFFI
    if n == "aiohttp":
        return _AIOHTTP
    if n == "httpx":
        return True
    return False


def _normalize_curl_impersonate(name: str) -> str:
    """
    Map friendly aliases to concrete profiles (curl_cffi.requests.impersonate).
    """
    n = (name or "chrome120").strip().lower()
    aliases = {
        "chrome": "chrome120",
        "edge": "edge101",
        "safari": "safari155",
        "firefox": "firefox133",
    }
    return aliases.get(n, n)


def _curl_profile_chain(preferred: str) -> list[Optional[str]]:
    """
    Order matters: None = vanilla curl TLS (no JA3 impersonation). Then user preference,
    then progressively older Chrome builds and other engines — skips duplicates.
    """
    primary = _normalize_curl_impersonate(preferred)
    ordered: list[Optional[str]] = [
        None,
        primary,
        "chrome110",
        "chrome107",
        "chrome104",
        "chrome101",
        "chrome100",
        "chrome99",
        "chrome116",
        "chrome120",
        "safari155",
        "safari153",
        "firefox133",
        "firefox135",
        "edge101",
        "edge99",
    ]
    seen: set[str] = set()
    out: list[Optional[str]] = []
    for token in ordered:
        key = "__plain__" if token is None else token
        if key not in seen:
            seen.add(key)
            out.append(token)
    return out


def _is_impersonate_unsupported(exc: BaseException) -> bool:
    cls = exc.__class__.__name__
    if cls == "ImpersonateError":
        return True
    msg = str(exc).lower()
    return "impersonat" in msg and "not supported" in msg


def _should_try_next_curl_profile(exc: BaseException) -> bool:
    """Rotate preset on missing bundle, timeouts (libcurl 28), or stalled reads."""
    if _is_impersonate_unsupported(exc):
        return True
    msg = str(exc).lower()
    if "errcode: 28" in msg or "error 28" in msg:
        return True
    if "operation timed out" in msg or "connection timed out" in msg:
        return True
    if "timeout" in msg and ("millisecond" in msg or "second" in msg):
        return True
    if "0 bytes received" in msg:
        return True
    return False


def resolve_backend(preferred: str) -> str:
    """Pick first working backend: preferred, then curl_cffi, aiohttp, httpx."""
    order = [preferred, "curl_cffi", "aiohttp", "httpx"]
    seen: set[str] = set()
    for name in order:
        key = (name or "").strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        if backend_available(key):
            if key != (preferred or "").strip().lower():
                log.warning(
                    "UIDAI_HTTP_BACKEND=%s unavailable; using %s instead",
                    preferred,
                    key,
                )
            return key
    return "httpx"


async def fetch_curl_cffi(
    method: str,
    url: str,
    headers: dict[str, str],
    payload: Optional[dict[str, Any]],
    *,
    impersonate: str = "chrome120",
    timeout_seconds: float = 25.0,
    connect_timeout: float = 8.0,
    sock_read_timeout: Optional[float] = None,
) -> tuple[int, dict[str, str], str]:
    if not _CURL_CFFI or CurlAsyncSession is None:
        raise UidaiTransportError("curl_cffi is not installed")

    last_exc: Optional[BaseException] = None
    for profile in _curl_profile_chain(impersonate):
        label = "plain_tls" if profile is None else profile
        try:
            async with CurlAsyncSession() as session:
                if sock_read_timeout is not None:
                    # Tuple (connect, read) — single-float ``timeout`` often caps long reads (~25s).
                    curl_timeout: Any = (float(connect_timeout), float(sock_read_timeout))
                else:
                    curl_timeout = float(timeout_seconds)
                req_kw: dict[str, Any] = {
                    "method": method,
                    "url": url,
                    "headers": headers,
                    "json": payload,
                    "timeout": curl_timeout,
                }
                if profile is not None:
                    req_kw["impersonate"] = profile
                r = await session.request(**req_kw)
            status = int(r.status_code)
            hdrs = {k: str(v) for k, v in r.headers.items()}
            text = r.text if r.text is not None else ""
            log.info("curl_cffi success impersonate=%s", label)
            return status, hdrs, text
        except UidaiTransportError:
            raise
        except Exception as exc:
            last_exc = exc
            if _should_try_next_curl_profile(exc):
                log.warning(
                    "curl_cffi impersonate=%s failed (%s); trying next TLS profile",
                    label,
                    exc,
                )
                continue
            raise UidaiTransportError(f"{exc.__class__.__name__}: {exc}") from exc

    raise UidaiTransportError(f"{last_exc.__class__.__name__}: {last_exc}") from last_exc


async def fetch_aiohttp(
    method: str,
    url: str,
    headers: dict[str, str],
    payload: Optional[dict[str, Any]],
    *,
    total_timeout: float = 25.0,
    connect_timeout: float = 8.0,
    sock_read_timeout: float = 25.0,
) -> tuple[int, dict[str, str], str]:
    if not _AIOHTTP or aiohttp is None:
        raise UidaiTransportError("aiohttp is not installed")
    timeout = aiohttp.ClientTimeout(
        total=total_timeout,
        connect=connect_timeout,
        sock_read=sock_read_timeout,
    )
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.request(
                method,
                url,
                headers=headers,
                json=payload,
                ssl=True,
            ) as resp:
                status = int(resp.status)
                hdrs = {k: v for k, v in resp.headers.items()}
                text = await resp.text()
                log.info("aiohttp transport success HTTP %s", status)
                return status, hdrs, text
    except UidaiTransportError:
        raise
    except Exception as exc:
        raise UidaiTransportError(f"{exc.__class__.__name__}: {exc}") from exc
