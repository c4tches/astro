"""Runtime policy placeholder; gating features are disabled."""

from __future__ import annotations


class RuntimePolicyStore:
    def __init__(self, file_path: str) -> None:
        self.file_path = file_path

    def load(self) -> None:
        return None

    def save(self) -> None:
        return None

    def free_mode_active(self) -> bool:
        return False

    def free_until_unix(self) -> float | None:
        return None

    def set_free_window_minutes(self, minutes: int) -> None:
        return None
