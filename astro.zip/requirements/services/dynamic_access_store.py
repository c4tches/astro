"""Runtime delegate-admin grants stored in JSON."""

from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class TimedGrant:
    chat_id: int
    expires_at: float | None
    added_by: int
    created_at: float
    usage_limit: int = 0


class DynamicAccessStore:
    def __init__(self, file_path: str) -> None:
        self.path = Path(file_path)
        self._lock = threading.RLock()
        self._delegates: dict[int, dict[str, Any]] = {}
        self.load()

    def load(self) -> None:
        with self._lock:
            if not self.path.exists():
                self._delegates = {}
                return
            try:
                raw = json.loads(self.path.read_text() or "{}")
            except Exception:
                self._delegates = {}
                return
            self._delegates = {int(k): dict(v) for k, v in (raw.get("delegates") or {}).items() if str(k).lstrip("-").isdigit()}
            self._prune_locked()

    def save(self) -> None:
        with self._lock:
            self._prune_locked()
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps({"delegates": {str(k): dict(v) for k, v in self._delegates.items()}}, indent=2, sort_keys=True))

    def _prune_locked(self) -> None:
        now = time.time()
        for cid, row in list(self._delegates.items()):
            exp = row.get("expires_at")
            if exp is not None and float(exp) <= now:
                self._delegates.pop(cid, None)

    def is_active_delegate_admin(self, chat_id: int) -> bool:
        with self._lock:
            self._prune_locked()
            return chat_id in self._delegates

    def grant_delegate_admin(self, chat_id: int, *, seconds: int, added_by: int) -> float | None:
        created = time.time()
        expires_at = None if seconds <= 0 else created + int(seconds)
        with self._lock:
            self._delegates[int(chat_id)] = {"expires_at": expires_at, "added_by": int(added_by), "created_at": created}
            self.save()
        return expires_at

    def revoke_delegate_admin(self, chat_id: int) -> bool:
        with self._lock:
            existed = int(chat_id) in self._delegates
            self._delegates.pop(int(chat_id), None)
            self.save()
            return existed

    def list_delegate_rows(self) -> list[TimedGrant]:
        with self._lock:
            self._prune_locked()
            return [TimedGrant(chat_id=cid, expires_at=v.get("expires_at"), added_by=int(v.get("added_by") or 0), created_at=float(v.get("created_at") or 0)) for cid, v in sorted(self._delegates.items())]
