import asyncio
import html
import logging
from typing import Any, Literal

from aiogram import Bot, Dispatcher, F, Router
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import BufferedInputFile, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, User

from config import Settings, get_settings
from handlers.admin_panel import build_admin_router
from logging_config import configure_logging
from services.analytics_store import AnalyticsStore
from services.pdf_archive import archive_plain_pdf
from services.dynamic_access_store import DynamicAccessStore
from services.result_store import ResultStore
from services.runtime_policy import RuntimePolicyStore
from services.session_store import FlowSession, SessionStore
from services.admin_failure_log import AdminFailureLog
from services.captcha_ocr_solver import (
    check_tesseract_available,
    solve_uidai_captcha_pipeline_async,
)
from services.uidai_client import (
    CaptchaResult,
    UidaiCaptchaRejectedError,
    UidaiClient,
    UidaiClientError,
    UidaiFlowBlockedError,
)
from utils.pdf_tools import decrypt_pdf_and_extract_details
from utils.sanitize import mask_mobile_for_log
from utils.validators import (
    validate_captcha,
    validate_eid,
    validate_mobile,
    validate_name,
    validate_otp,
    validate_uidai_captcha_strict,
)

settings = get_settings()
configure_logging(
    log_level=settings.log_level,
    log_file=settings.log_file,
    log_to_console=settings.log_to_console,
)

log = logging.getLogger(__name__)

analytics = AnalyticsStore(settings.analytics_file)
runtime_policy = RuntimePolicyStore(settings.runtime_policy_file)
dynamic_access = DynamicAccessStore(settings.dynamic_access_file)


class RetrieveEidFlow(StatesGroup):
    await_mode = State()
    await_mobile = State()
    await_name = State()
    await_captcha = State()
    await_otp = State()
    await_pdf_eid = State()
    await_pdf_name = State()
    await_download_captcha = State()
    await_download_otp = State()


router = Router()
session_store = SessionStore()
uidai_client = UidaiClient(
    base_url=settings.api_base_url,
    app_id=settings.app_id,
    timeout_seconds=settings.request_timeout_seconds,
    max_retries=settings.max_retries,
    connect_timeout_seconds=settings.connect_timeout_seconds,
    read_timeout_seconds=settings.read_timeout_seconds,
    pdf_download_read_timeout_seconds=settings.pdf_download_read_timeout_seconds,
    write_timeout_seconds=settings.write_timeout_seconds,
    pool_timeout_seconds=settings.pool_timeout_seconds,
    http_max_connections=settings.http_max_connections,
    http_max_keepalive_connections=settings.http_max_keepalive_connections,
    captcha_audio_required=settings.captcha_audio_required,
    user_agent=settings.uidai_user_agent,
    captcha_ephemeral_client=settings.captcha_ephemeral_client,
    uidai_http_backend=settings.uidai_http_backend,
    captcha_connection_close=settings.captcha_connection_close,
    curl_impersonate=settings.curl_impersonate,
    diagnose_before_uidai_request=settings.diagnose_before_uidai_request,
    transport_fallback=settings.transport_fallback,
    randomize_user_agent=settings.randomize_user_agent,
)
result_store = ResultStore(settings.results_file)
failure_log = AdminFailureLog(settings.admin_failure_log_file)

FLOW_CANCEL_CB = "flow:cancel"


def _admin_flow_failure(message: Message | None, kind: str, detail: str) -> None:
    try:
        cid = int(message.chat.id) if message and message.chat else 0
        un = message.from_user.username if message and message.from_user else None
        failure_log.append(kind=kind[:120], chat_id=cid, username=un, detail=detail[:800])
    except Exception:
        log.exception("admin_failure_log_append_error")


def cancel_only_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="â¬…ï¸ Main menu", callback_data=FLOW_CANCEL_CB)]]
    )


async def _try_auto_solve_eid_captcha(
    message: Message,
    state: FSMContext,
    *,
    chat_id: int,
    request_id: str,
    mobile_number: str,
    name: str,
    initial: CaptchaResult,
) -> tuple[Literal["ok", "manual", "blocked"], CaptchaResult]:
    """Automatically solve captcha and request OTP.

    Returns (status, latest_captcha_result).
    ``ok`` â€” OTP sent.
    ``blocked`` â€” UIDAI refused OTP without a captcha error (session cleared; user notified).
    ``manual`` â€” Fall back to showing the captcha image.
    """
    if not settings.captcha_auto_solve:
        return "manual", initial

    rounds = max(1, settings.captcha_auto_solve_attempts)
    captcha_result = initial

    for attempt in range(rounds):
        sess = session_store.get(chat_id)
        if not sess:
            return "manual", captcha_result
        sess.captcha_txn_id = captcha_result.captcha_txn_id
        session_store.set(chat_id, sess)

        guess = await solve_uidai_captcha_pipeline_async(
            captcha_result.image_bytes,
            gemini_api_key=settings.gemini_api_key,
            gemini_models=settings.gemini_captcha_models,
            gemini_timeout_seconds=settings.gemini_captcha_timeout_seconds,
            tesseract_cmd=settings.tesseract_cmd,
            min_word_confidence=settings.captcha_ocr_min_confidence,
            consensus_min_confidence=settings.captcha_ocr_consensus_confidence,
            consensus_min_votes=settings.captcha_ocr_consensus_votes,
            gemini_parallel=settings.gemini_captcha_parallel,
            gemini_parallel_max=settings.gemini_captcha_parallel_max,
        )
        ok_g, text = validate_uidai_captcha_strict(guess)
        if ok_g:
            try:
                otp_result = await uidai_client.request_otp(
                    request_id=request_id,
                    mobile_number=mobile_number,
                    name=name,
                    captcha_txn_id=captcha_result.captcha_txn_id,
                    captcha_text=text,
                )
            except UidaiFlowBlockedError as exc:
                log.info(
                    "captcha_auto_eid_flow_blocked chat_id=%s attempt=%s err=%s",
                    chat_id,
                    attempt,
                    exc,
                )
                _admin_flow_failure(message, "uidai_otp_blocked_auto", str(exc))
                await state.clear()
                session_store.clear(chat_id)
                await message.answer(
                    "<b>UIDAI did not send an OTP</b>\n"
                    f"{html.escape(str(exc))}\n\n"
                    "Your captcha was accepted, but UIDAI did not issue an OTP for this "
                    "mobile number and name â€” responses such as "
                    "<b>No Records Found</b> usually mean no matching enrollment.\n\n"
                    "Confirm the exact name printed on your Aadhaar and that this mobile "
                    "is linked to UIDAI on the official MyAadhaar site. A different API key or "
                    "new captcha will not fix mismatched records.\n\n"
                    "Use /start after correcting the details.",
                    parse_mode=ParseMode.HTML,
                )
                return "blocked", captcha_result
            except UidaiCaptchaRejectedError as exc:
                log.warning(
                    "captcha_auto_eid_invalid_captcha attempt=%s chat_id=%s err=%s",
                    attempt,
                    chat_id,
                    exc,
                )
                if attempt < rounds - 1:
                    try:
                        captcha_result = await uidai_client.generate_captcha(request_id)
                    except UidaiClientError as gen_exc:
                        log.error("captcha_auto_regen_failed chat_id=%s err=%s", chat_id, gen_exc)
                        _admin_flow_failure(message, "captcha_regen_failed", str(gen_exc))
                        return "manual", captcha_result
                    continue
                _admin_flow_failure(message, "uidai_captcha_rejected_auto", str(exc))
                return "manual", captcha_result
            except UidaiClientError as exc:
                log.warning(
                    "captcha_auto_eid_otp_fail attempt=%s chat_id=%s err=%s",
                    attempt,
                    chat_id,
                    exc,
                )
                if attempt < rounds - 1:
                    try:
                        captcha_result = await uidai_client.generate_captcha(request_id)
                    except UidaiClientError as gen_exc:
                        log.error("captcha_auto_regen_failed chat_id=%s err=%s", chat_id, gen_exc)
                        _admin_flow_failure(message, "captcha_regen_failed", str(gen_exc))
                        return "manual", captcha_result
                    continue
                _admin_flow_failure(message, "uidai_otp_request_failed_auto", str(exc))
                return "manual", captcha_result

            sess = session_store.get(chat_id)
            if not sess:
                return "manual", captcha_result
            sess.otp_txn_id = otp_result.otp_txn_id
            session_store.set(chat_id, sess)
            await state.update_data(captcha_text=text)
            await state.set_state(RetrieveEidFlow.await_otp)
            await message.answer(
                "<b>Captcha solved automatically</b>\n"
                f"<b>OTP sent</b>\n{html.escape(str(otp_result.message))}\n\n"
                "<b>Step 4</b> â€” Enter the 6-digit OTP from your SMS.",
                parse_mode=ParseMode.HTML,
                reply_markup=cancel_only_keyboard(),
            )
            log.info("captcha_auto_eid_ok chat_id=%s attempt=%s", chat_id, attempt)
            return "ok", captcha_result

        log.info("captcha_auto_eid_ocr_miss attempt=%s chat_id=%s", attempt, chat_id)
        if attempt < rounds - 1:
            try:
                captcha_result = await uidai_client.generate_captcha(request_id)
            except UidaiClientError as gen_exc:
                log.error("captcha_auto_regen_failed chat_id=%s err=%s", chat_id, gen_exc)
                _admin_flow_failure(message, "captcha_regen_failed", str(gen_exc))
                return "manual", captcha_result
            continue

    return "manual", captcha_result


async def _try_auto_solve_download_otp_captcha(
    message: Message,
    state: FSMContext,
    *,
    chat_id: int,
    request_id: str,
    initial: CaptchaResult,
) -> tuple[bool, CaptchaResult]:
    """Return (True, latest_captcha) when PDF download OTP request succeeds."""
    if not settings.captcha_auto_solve:
        return False, initial

    rounds = max(1, settings.captcha_auto_solve_attempts)
    captcha_result = initial

    for attempt in range(rounds):
        sess = session_store.get(chat_id)
        if not sess or not sess.eid_number:
            return False, captcha_result
        sess.download_captcha_txn_id = captcha_result.captcha_txn_id
        session_store.set(chat_id, sess)

        guess = await solve_uidai_captcha_pipeline_async(
            captcha_result.image_bytes,
            gemini_api_key=settings.gemini_api_key,
            gemini_models=settings.gemini_captcha_models,
            gemini_timeout_seconds=settings.gemini_captcha_timeout_seconds,
            tesseract_cmd=settings.tesseract_cmd,
            min_word_confidence=settings.captcha_ocr_min_confidence,
            consensus_min_confidence=settings.captcha_ocr_consensus_confidence,
            consensus_min_votes=settings.captcha_ocr_consensus_votes,
            gemini_parallel=settings.gemini_captcha_parallel,
            gemini_parallel_max=settings.gemini_captcha_parallel_max,
        )
        ok_g, text = validate_uidai_captcha_strict(guess)
        if ok_g:
            try:
                otp_result = await uidai_client.request_download_otp(
                    request_id=request_id,
                    eid_number=sess.eid_number,
                    captcha_txn_id=captcha_result.captcha_txn_id,
                    captcha_text=text,
                )
            except UidaiClientError as exc:
                log.warning(
                    "captcha_auto_dl_otp_fail attempt=%s chat_id=%s err=%s",
                    attempt,
                    chat_id,
                    exc,
                )
                if attempt < rounds - 1:
                    try:
                        captcha_result = await uidai_client.generate_captcha(request_id)
                    except UidaiClientError as gen_exc:
                        log.error("captcha_auto_regen_failed chat_id=%s err=%s", chat_id, gen_exc)
                        _admin_flow_failure(message, "captcha_regen_failed", str(gen_exc))
                        return False, captcha_result
                    continue
                _admin_flow_failure(message, "uidai_pdf_otp_failed_auto", str(exc))
                return False, captcha_result

            sess = session_store.get(chat_id)
            if not sess:
                return False, captcha_result
            sess.download_otp_txn_id = otp_result.otp_txn_id
            sess.download_captcha_text = text
            session_store.set(chat_id, sess)
            await state.set_state(RetrieveEidFlow.await_download_otp)
            await message.answer(
                "<b>Captcha solved automatically</b>\n"
                f"<b>OTP sent</b>\n{html.escape(str(otp_result.message))}\n\n"
                "Send the <b>6-digit OTP</b> for PDF download.",
                parse_mode=ParseMode.HTML,
                reply_markup=cancel_only_keyboard(),
            )
            log.info("captcha_auto_download_ok chat_id=%s attempt=%s", chat_id, attempt)
            return True, captcha_result

        log.info("captcha_auto_dl_ocr_miss attempt=%s chat_id=%s", attempt, chat_id)
        if attempt < rounds - 1:
            try:
                captcha_result = await uidai_client.generate_captcha(request_id)
            except UidaiClientError as gen_exc:
                log.error("captcha_auto_regen_failed chat_id=%s err=%s", chat_id, gen_exc)
                _admin_flow_failure(message, "captcha_regen_failed", str(gen_exc))
                return False, captcha_result
            continue

    return False, captcha_result


def _telegram_full_name(user: User | None) -> str | None:
    if not user:
        return None
    parts = [user.first_name or "", user.last_name or ""]
    name = " ".join(p for p in parts if p).strip()
    return name or None


def _welcome_first_name(user: User | None) -> str:
    if user and user.first_name:
        return user.first_name.strip()
    full = _telegram_full_name(user)
    return full if full else "there"


def help_text() -> str:
    lines = [
        "<b>Aadhaar Helper â€” Quick help</b>\n",
        "â€¢ /start â€” open the main menu\n",
        "â€¢ /cancel â€” stop the current step (same as <b>â¬…ï¸ Main menu</b>)\n",
        "â€¢ /restart â€” back to the menu\n",
        "â€¢ /netcheck â€” test connection to UIDAI\n",
        "â€¢ /panel â€” admin (authorized accounts only)",
    ]
    return "".join(lines)


def is_usage_limit_reached(chat_id: int) -> bool:
    return False


def can_use_services(chat_id: int) -> bool:
    return True


def show_access_notice_button(chat_id: int) -> bool:
    return False


def access_restricted_html(chat_id: int) -> str:
    return "<b>Aadhaar Helper</b>\n\nSend /start to open the main menu."


def access_restricted_text(chat_id: int) -> str:
    return access_restricted_html(chat_id)


def access_restricted_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="â¬…ï¸ Main menu", callback_data=FLOW_CANCEL_CB)]]
    )


def main_menu_keyboard(*, show_access_notice: bool = False) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(text="ðŸ“„ Retrieve EID + PDF", callback_data="mode:both"),
            InlineKeyboardButton(text="ðŸ”¢ EID only", callback_data="mode:eid_only"),
        ],
        [InlineKeyboardButton(text="â¬‡ï¸ Download Aadhaar by EID", callback_data="mode:pdf_only")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def deliver_flow_cancel(message: Message, state: FSMContext) -> None:
    if not message.chat:
        return
    chat_id = message.chat.id
    session_store.clear(chat_id)
    await state.clear()
    await state.set_state(RetrieveEidFlow.await_mode)
    show_access_notice = show_access_notice_button(chat_id)
    await message.answer(
        "<b>Session cleared</b>\nPick your next action below.",
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_keyboard(show_access_notice=show_access_notice),
    )


def free_window_blocks(chat_id: int) -> tuple[bool, int]:
    return False, 0


async def send_cooldown_message(message: Message, seconds_left: int, chat_id: int) -> None:
    await message.answer(
        "<b>Aadhaar Helper</b>\n\nPlease use /start to open the main menu.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message(CommandStart())
async def on_start(message: Message, state: FSMContext) -> None:
    if not message.chat:
        return
    chat_id = message.chat.id
    uname = message.from_user.username if message.from_user else None
    t_full = _telegram_full_name(message.from_user)
    analytics.touch_user(chat_id, username=uname, full_name=t_full)


    await state.clear()
    session_store.clear(chat_id)
    await state.set_state(RetrieveEidFlow.await_mode)
    greet = _welcome_first_name(message.from_user)
    analytics.touch_user(chat_id, username=uname, full_name=t_full, record_start=True)

    status_html = ""

    show_access_notice = show_access_notice_button(chat_id)

    await message.answer(
        f"{status_html}\n\n"
        "<b>Aadhaar Helper</b> âœ¨\n\n"
        f"Hello <b>{html.escape(greet)}</b>, welcome back!\n\n"
        "<b>Here's what I can help with:</b>\n"
        "â€¢ <b>Linked PDF</b> â€” fetch your Enrolment ID, then download & unlock your Aadhaar PDF\n"
        "â€¢ <b>EID only</b> â€” get your 28-digit Enrolment ID from mobile + OTP\n"
        "â€¢ <b>PDF by EID</b> â€” download the PDF when you already have the EID\n\n"
        "<b>Before you begin</b>\n"
        "Keep the registered mobile nearby â€” UIDAI will send OTPs.\n"
        "Pick an option below to continue.",
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_keyboard(show_access_notice=show_access_notice),
    )


@router.callback_query(RetrieveEidFlow.await_mode, F.data.startswith("mode:"))
async def handle_mode_callback(cq: CallbackQuery, state: FSMContext) -> None:
    if not cq.message or not cq.from_user:
        return
    chat_id = cq.from_user.id
    data = cq.data or ""
    mode = data.split(":", 1)[-1].strip()

    if not can_use_services(chat_id):
        await cq.answer("Service access required.", show_alert=True)
        return

    blocks, secs = free_window_blocks(chat_id)
    if blocks:
        await cq.answer(
            f"Please wait ~{(secs + 59) // 60} min before another run (free window).",
            show_alert=True,
        )
        return

    if mode not in ("both", "eid_only", "pdf_only"):
        await cq.answer("Unknown option.", show_alert=True)
        return

    await cq.answer()
    mode_labels = {"both": "EID + PDF", "eid_only": "EID only", "pdf_only": "PDF by EID"}
    analytics.append_event(chat_id, "mode", mode_labels.get(mode, mode))
    if mode == "both":
        await state.update_data(flow_mode="both")
        await state.set_state(RetrieveEidFlow.await_mobile)
        await cq.message.answer(
            "<b>Step 1/4</b> â€” Mobile number\n"
            "Send a valid <b>10-digit</b> Indian mobile number registered with Aadhaar.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
        return
    if mode == "eid_only":
        await state.update_data(flow_mode="eid_only")
        await state.set_state(RetrieveEidFlow.await_mobile)
        await cq.message.answer(
            "<b>Step 1/3</b> â€” Mobile number\n"
            "Send a valid <b>10-digit</b> Indian mobile number registered with Aadhaar.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
        return
    if mode == "pdf_only":
        await state.update_data(flow_mode="pdf_only")
        await state.set_state(RetrieveEidFlow.await_pdf_eid)
        await cq.message.answer(
            "<b>Step 1/3</b> â€” Enrolment ID\n"
            "Send your <b>28-digit EID</b> (digits only).",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
        return


@router.message(Command("help"))
async def on_help(message: Message) -> None:
    if not message.chat:
        await message.answer(help_text(), parse_mode=ParseMode.HTML)
        return
    cid = message.chat.id
    body = help_text()
    kb = cancel_only_keyboard()
    if not can_use_services(cid):
        body += "\n\n" + access_restricted_html(cid)
        kb = access_restricted_keyboard()
    await message.answer(body, parse_mode=ParseMode.HTML, reply_markup=kb, disable_web_page_preview=True)


@router.message(Command("netcheck"))
async def on_netcheck(message: Message) -> None:
    await message.answer(
        "Running a quick connectivity checkâ€¦",
        reply_markup=cancel_only_keyboard(),
    )
    report = await uidai_client.diagnose_connectivity()
    dns_list = report.get("dns_resolved") or []
    dns_text = ", ".join(dns_list) if dns_list else "none"
    if report.get("tcp_ok"):
        await message.answer(
            "<b>Connectivity OK</b>\n"
            f"I can reach the UIDAI host on TCP.\n"
            f"<code>{report.get('host')}:{report.get('port')}</code>",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
        return
    await message.answer(
        "<b>Connectivity issue</b>\n"
        f"Host: <code>{report.get('host')}:{report.get('port')}</code>\n"
        f"DNS: {dns_text}\n"
        "The network path looks blocked or unstable. Try another network/VPN later.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message(Command("cancel"))
async def on_cancel(message: Message, state: FSMContext) -> None:
    if not message.chat:
        return
    await deliver_flow_cancel(message, state)


@router.callback_query(F.data == FLOW_CANCEL_CB)
async def on_flow_cancel_callback(cq: CallbackQuery, state: FSMContext) -> None:
    if not cq.message or not cq.from_user:
        await cq.answer()
        return
    await cq.answer("Main menu.")
    await deliver_flow_cancel(cq.message, state)


@router.message(Command("restart"))
async def on_restart(message: Message, state: FSMContext) -> None:
    await on_start(message, state)


@router.message(RetrieveEidFlow.await_mobile, F.text)
async def handle_mobile(message: Message, state: FSMContext) -> None:
    ok, mobile = validate_mobile(message.text or "")
    if not ok:
        await message.answer(
            "That does not look like a valid 10-digit mobile. Please try again.",
            reply_markup=cancel_only_keyboard(),
        )
        return

    log.info("step_mobile_ok chat_id=%s mobile=%s", message.chat.id, mask_mobile_for_log(mobile))
    await state.update_data(mobile_number=mobile)
    await state.set_state(RetrieveEidFlow.await_name)
    await message.answer(
        "<b>Step 2</b> â€” Name\n"
        "Enter the <b>full name</b> (letters and spaces, as used during enrolment).",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message(RetrieveEidFlow.await_name, F.text)
async def handle_name(message: Message, state: FSMContext) -> None:
    ok, name = validate_name(message.text or "")
    if not ok:
        await message.answer(
            "Please use letters and spaces only (about 2â€“60 characters).",
            reply_markup=cancel_only_keyboard(),
        )
        return

    data = await state.get_data()
    mobile_number = data.get("mobile_number")
    flow_mode = data.get("flow_mode", "both")
    if not mobile_number:
        await state.clear()
        await message.answer("Session expired. Please tap /start.")
        return

    request_id = uidai_client.new_request_id()
    await message.answer(
        "<b>Workingâ€¦</b>\nPreparing a captcha for you.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )
    try:
        captcha_result = await uidai_client.generate_captcha(request_id=request_id)
    except UidaiClientError as exc:
        log.error("captcha_generation_failed chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "captcha_generation_failed", str(exc))
        await state.clear()
        await message.answer(
            "<b>Something went wrong</b>\n"
            "Could not load a captcha right now. Please try /start again in a minute.",
            parse_mode=ParseMode.HTML,
        )
        return
    except Exception:
        log.exception("captcha_generation_unexpected chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "captcha_generation_unexpected", "non-Uidai error during captcha fetch")
        await state.clear()
        await message.answer("Unexpected error while preparing captcha. Use /start to retry.")
        return

    session_store.set(
        message.chat.id,
        FlowSession(
            request_id=request_id,
            mobile_number=mobile_number,
            name=name,
            input_mobile=mobile_number,
            input_name=name,
            captcha_txn_id=captcha_result.captcha_txn_id,
            mode=str(flow_mode),
        ),
    )
    await state.set_state(RetrieveEidFlow.await_captcha)

    auto_out, captcha_result = await _try_auto_solve_eid_captcha(
        message,
        state,
        chat_id=message.chat.id,
        request_id=request_id,
        mobile_number=mobile_number,
        name=name,
        initial=captcha_result,
    )
    if auto_out == "ok":
        return
    if auto_out == "blocked":
        return

    try:
        await message.answer_photo(
            photo=BufferedInputFile(captcha_result.image_bytes, filename="captcha.jpg"),
            caption=(
                "<b>Step 3</b> â€” Captcha\n"
                "Type the characters you see. I will request the OTP next.\n\n"
                "<i>If the image is unclear, use /restart.</i>"
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
    except Exception:
        log.exception("telegram_answer_photo_failed chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "telegram_captcha_photo_failed", "answer_photo failed after captcha fetch")
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Captcha was received but could not be shown in Telegram. Please try /start.")
        return


@router.message(RetrieveEidFlow.await_pdf_eid, F.text)
async def handle_pdf_mode_eid(message: Message, state: FSMContext) -> None:
    ok, eid = validate_eid(message.text or "")
    if not ok:
        await message.answer(
            "Please send exactly 28 digits for the EID.",
            reply_markup=cancel_only_keyboard(),
        )
        return
    await state.update_data(pdf_only_eid=eid)
    await state.set_state(RetrieveEidFlow.await_pdf_name)
    await message.answer(
        "<b>Step 2</b> â€” Name on Aadhaar\n"
        "Enter the name as printed on Aadhaar (used only until UIDAI confirms details).",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message(RetrieveEidFlow.await_pdf_name, F.text)
async def handle_pdf_mode_name(message: Message, state: FSMContext) -> None:
    ok, name = validate_name(message.text or "")
    if not ok:
        await message.answer(
            "Please use letters and spaces only (about 2â€“60 characters).",
            reply_markup=cancel_only_keyboard(),
        )
        return
    data = await state.get_data()
    eid = data.get("pdf_only_eid")
    if not eid:
        await state.clear()
        await message.answer("Session expired. Use /start.")
        return
    request_id = uidai_client.new_request_id()
    await message.answer(
        "<b>Workingâ€¦</b>\nPreparing captcha for download.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )
    try:
        captcha_result = await uidai_client.generate_captcha(request_id=request_id)
    except UidaiClientError as exc:
        _admin_flow_failure(message, "pdf_only_captcha_generation_failed", str(exc))
        await state.clear()
        await message.answer(
            "<b>Could not continue</b>\n"
            f"{exc}\nPlease /start again shortly.",
            parse_mode=ParseMode.HTML,
        )
        return
    except Exception:
        log.exception("pdf_only_captcha_generation_unexpected chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "pdf_only_captcha_generation_unexpected", "unexpected error during pdf captcha fetch")
        await state.clear()
        await message.answer("Unexpected error while preparing captcha. Use /start.")
        return
    session_store.set(
        message.chat.id,
        FlowSession(
            request_id=request_id,
            name=name,
            input_name=name,
            input_mobile="",
            captcha_txn_id=captcha_result.captcha_txn_id,
            mode="pdf_only",
            eid_number=eid,
            download_captcha_txn_id=captcha_result.captcha_txn_id,
        ),
    )
    await state.set_state(RetrieveEidFlow.await_download_captcha)

    ok_auto, captcha_result = await _try_auto_solve_download_otp_captcha(
        message,
        state,
        chat_id=message.chat.id,
        request_id=request_id,
        initial=captcha_result,
    )
    if ok_auto:
        return

    await message.answer_photo(
        photo=BufferedInputFile(captcha_result.image_bytes, filename="download_captcha.jpg"),
        caption=(
            "<b>Step 3</b> â€” Captcha\n"
            "Type the characters you see. I will send an OTP for PDF download next."
        ),
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message(RetrieveEidFlow.await_captcha, F.text)
async def handle_captcha(message: Message, state: FSMContext) -> None:
    ok, captcha_text = validate_captcha(message.text or "")
    if not ok:
        await message.answer(
            "Captcha should be 4â€“12 letters or numbers.",
            reply_markup=cancel_only_keyboard(),
        )
        return

    session = session_store.get(message.chat.id)
    if not session:
        await state.clear()
        await message.answer("Session expired. Use /start.")
        return

    await message.answer(
        "<b>Almost thereâ€¦</b>\nRequesting OTP.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )
    try:
        otp_result = await uidai_client.request_otp(
            request_id=session.request_id,
            mobile_number=session.mobile_number,
            name=session.name,
            captcha_txn_id=session.captcha_txn_id,
            captcha_text=captcha_text,
        )
    except UidaiFlowBlockedError as exc:
        log.info("otp_request_flow_blocked chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "uidai_otp_blocked_manual", str(exc))
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer(
            "<b>UIDAI did not send an OTP</b>\n"
            f"{html.escape(str(exc))}\n\n"
            "The captcha was accepted; check that mobile and full name match your Aadhaar "
            "record on the official portal, then use /start.",
            parse_mode=ParseMode.HTML,
        )
        return
    except UidaiCaptchaRejectedError as exc:
        log.warning("otp_request_invalid_captcha chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "uidai_captcha_rejected_manual", str(exc))
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer(
            "<b>Invalid or expired captcha</b>\n"
            f"{html.escape(str(exc))}\n\n"
            "Please use /start and try again.",
            parse_mode=ParseMode.HTML,
        )
        return
    except UidaiClientError as exc:
        log.warning("otp_request_failed chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "uidai_otp_request_failed_manual", str(exc))
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer(
            "<b>OTP request failed</b>\n"
            f"{html.escape(str(exc))}\n\n"
            "Please /start and try again.",
            parse_mode=ParseMode.HTML,
        )
        return
    except Exception:
        log.exception("otp_request_unexpected chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "otp_request_unexpected", "unexpected error during OTP request")
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Unexpected error during OTP request. Use /start.")
        return

    session.otp_txn_id = otp_result.otp_txn_id
    session_store.set(message.chat.id, session)
    await state.update_data(captcha_text=captcha_text)
    await state.set_state(RetrieveEidFlow.await_otp)
    await message.answer(
        f"<b>OTP sent</b>\n{otp_result.message}\n\n"
        "<b>Step 4</b> â€” Enter the 6-digit OTP from your SMS.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message(RetrieveEidFlow.await_otp, F.text)
async def handle_otp(message: Message, state: FSMContext) -> None:
    ok, otp = validate_otp(message.text or "")
    if not ok:
        await message.answer(
            "Please send a 6-digit OTP.",
            reply_markup=cancel_only_keyboard(),
        )
        return

    session = session_store.get(message.chat.id)
    data = await state.get_data()
    captcha_text = data.get("captcha_text")
    if not session or not session.otp_txn_id or not captcha_text:
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Session expired. Use /start.")
        return

    await message.answer(
        "<b>Verifyingâ€¦</b>\nPlease wait.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )
    try:
        eid_result = await uidai_client.verify_otp_and_fetch_eid(
            request_id=session.request_id,
            mobile_number=session.mobile_number,
            name=session.name,
            otp=otp,
            otp_txn_id=session.otp_txn_id,
            captcha_txn_id=session.captcha_txn_id,
            captcha_text=captcha_text,
        )
    except UidaiClientError as exc:
        log.error("otp_verify_failed chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "otp_verify_failed", str(exc))
        await message.answer(
            "<b>Verification failed</b>\n"
            "Double-check the OTP and try /restart if needed.",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
        return
    except Exception:
        log.exception("otp_verify_unexpected chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "otp_verify_unexpected", "unexpected error during OTP verify")
        await message.answer(
            "Unexpected error during verification. Try /restart.",
            reply_markup=cancel_only_keyboard(),
        )
        return

    result_store.append_success(
        mobile_number=session.mobile_number,
        requested_name=session.input_name or session.name,
        resolved_name=eid_result.name,
        eid_number=eid_result.eid_number,
    )
    session.name = eid_result.name
    session.eid_number = eid_result.eid_number
    session.download_otp_txn_id = None
    session.download_captcha_txn_id = None
    session.download_captcha_text = None
    session_store.set(message.chat.id, session)
    await state.update_data(captcha_text=None)

    await message.answer(
        "<b>âœ… Enrolment ID ready</b>\n\n"
        f"Name (UIDAI): <b>{eid_result.name}</b>\n"
        f"EID: <code>{eid_result.eid_number}</code>",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )

    if session.mode == "eid_only":
        analytics.apply_metrics(message.chat.id, eid_delta=1, fire_cooldown=True)
        session_store.clear(message.chat.id)
        await state.set_state(RetrieveEidFlow.await_mode)
        await message.answer(
            "<b>All done</b>\nChoose another service below whenever you are ready.",
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_keyboard(show_access_notice=show_access_notice_button(message.chat.id)),
        )
        return

    analytics.apply_metrics(message.chat.id, eid_delta=1, fire_cooldown=False)
    await message.answer(
        "<b>Next</b>\nPreparing captcha for PDF downloadâ€¦",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )
    try:
        dl_captcha = await uidai_client.generate_captcha(request_id=session.request_id)
    except UidaiClientError as exc:
        log.error("download_captcha_generation_failed chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "download_captcha_generation_failed", str(exc))
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer(
            "<b>Could not continue</b>\n"
            "Download captcha failed. Please /restart and try the PDF step again.",
            parse_mode=ParseMode.HTML,
        )
        return
    except Exception:
        log.exception("download_captcha_generation_unexpected chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "download_captcha_generation_unexpected", "unexpected error after EID step")
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Unexpected error while preparing the next captcha. Use /restart.")
        return
    session.download_captcha_txn_id = dl_captcha.captcha_txn_id
    session_store.set(message.chat.id, session)
    await state.set_state(RetrieveEidFlow.await_download_captcha)

    ok_auto, dl_captcha = await _try_auto_solve_download_otp_captcha(
        message,
        state,
        chat_id=message.chat.id,
        request_id=session.request_id,
        initial=dl_captcha,
    )
    if ok_auto:
        return

    try:
        await message.answer_photo(
            photo=BufferedInputFile(dl_captcha.image_bytes, filename="download_captcha.jpg"),
            caption=(
                "<b>Captcha â€” PDF step</b>\n"
                "Type the characters you see. I will request the PDF OTP next."
            ),
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
    except Exception:
        log.exception("telegram_download_captcha_photo_failed chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "telegram_download_captcha_photo_failed", "answer_photo failed in PDF step")
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Could not display captcha in chat. Use /restart.")
        return


@router.message(RetrieveEidFlow.await_download_captcha, F.text)
async def handle_download_captcha(message: Message, state: FSMContext) -> None:
    ok, captcha_text = validate_captcha(message.text or "")
    if not ok:
        await message.answer(
            "Captcha should be 4â€“12 letters or numbers.",
            reply_markup=cancel_only_keyboard(),
        )
        return
    session = session_store.get(message.chat.id)
    if not session or not session.eid_number or not session.download_captcha_txn_id:
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Session expired. Use /restart.")
        return
    await message.answer(
        "<b>Requesting PDF OTPâ€¦</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )
    try:
        otp_result = await uidai_client.request_download_otp(
            request_id=session.request_id,
            eid_number=session.eid_number,
            captcha_txn_id=session.download_captcha_txn_id,
            captcha_text=captcha_text,
        )
    except UidaiClientError as exc:
        log.error("download_otp_request_failed chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "download_otp_request_failed", str(exc))
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer(
            "<b>OTP request failed</b>\nPlease /restart and try again.",
            parse_mode=ParseMode.HTML,
        )
        return
    except Exception:
        log.exception("download_otp_request_unexpected chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "download_otp_request_unexpected", "unexpected error during PDF OTP request")
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Unexpected error during PDF OTP request. Use /restart.")
        return
    session.download_otp_txn_id = otp_result.otp_txn_id
    session.download_captcha_text = captcha_text
    session_store.set(message.chat.id, session)
    await state.set_state(RetrieveEidFlow.await_download_otp)
    await message.answer(
        f"<b>OTP sent</b>\n{otp_result.message}\n\n"
        "Send the <b>6-digit OTP</b> for PDF download.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message(RetrieveEidFlow.await_download_otp, F.text)
async def handle_download_otp(message: Message, state: FSMContext) -> None:
    ok, otp = validate_otp(message.text or "")
    if not ok:
        await message.answer(
            "Please send a 6-digit OTP.",
            reply_markup=cancel_only_keyboard(),
        )
        return
    session = session_store.get(message.chat.id)
    if not session or not session.eid_number or not session.download_otp_txn_id:
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Session expired. Use /restart.")
        return
    await message.answer(
        "<b>Downloading PDFâ€¦</b>\nThis may take a little while.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )
    try:
        pdf_result = await uidai_client.download_aadhaar_pdf(
            request_id=session.request_id,
            eid=session.eid_number,
            otp=otp,
            otp_txn_id=session.download_otp_txn_id,
            mask=settings.pdf_download_mask,
        )
    except UidaiClientError as exc:
        log.error("aadhaar_pdf_download_failed chat_id=%s err=%s", message.chat.id, exc)
        _admin_flow_failure(message, "aadhaar_pdf_download_failed", str(exc))
        await state.clear()
        session_store.clear(message.chat.id)
        detail = html.escape(str(exc).strip())
        await message.answer(
            "<b>Download failed</b>\n"
            f"{detail}\n\n"
            "<i>If UIDAI mentions OTP limits, use /restart and request a new PDF OTP. "
            "Large PDF responses need a stable network.</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=cancel_only_keyboard(),
        )
        return
    except Exception:
        log.exception("aadhaar_pdf_download_unexpected chat_id=%s", message.chat.id)
        _admin_flow_failure(message, "aadhaar_pdf_download_unexpected", "unexpected error during PDF download")
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("Unexpected error during PDF download. Use /restart.")
        return
    filename = f"aadhaar_{(pdf_result.eid or session.eid_number)[-8:]}.pdf"
    out_pdf_bytes = pdf_result.pdf_bytes
    caption_lines = ["<b>Your Aadhaar PDF is attached.</b>"]
    if settings.pdf_decrypt_enabled:
        crack = decrypt_pdf_and_extract_details(pdf_result.pdf_bytes, session.name)
        if crack.success and crack.decrypted_pdf_bytes:
            out_pdf_bytes = crack.decrypted_pdf_bytes
            resolved_name_for_caption = crack.extracted_name or session.name
            if resolved_name_for_caption:
                caption_lines.append(f"Name: <b>{resolved_name_for_caption}</b>")
            try:
                archive_plain_pdf(
                    base_dir=settings.pdf_archive_dir,
                    chat_id=message.chat.id,
                    eid=session.eid_number or "",
                    aadhaar_number=crack.extracted_aadhaar_number,
                    user_mobile=session.input_mobile or session.mobile_number or "",
                    user_input_name=session.input_name or "",
                    server_name=session.name or "",
                    pdf_bytes=out_pdf_bytes,
                )
            except Exception:
                log.exception("pdf_archive_failed chat_id=%s", message.chat.id)
        else:
            caption_lines.append(
                "<i>Password not removed automatically â€” sending protected PDF.</i>\n"
                "If details look wrong, double-check the name on Aadhaar and try again."
            )
            log.warning("aadhaar_pdf_decrypt_failed chat_id=%s", message.chat.id)
    caption = "\n".join(caption_lines)
    try:
        await message.answer_document(
            document=BufferedInputFile(out_pdf_bytes, filename=filename),
            caption=caption,
            parse_mode=ParseMode.HTML,
        )
    except Exception:
        log.exception("telegram_send_pdf_failed chat_id=%s", message.chat.id)
        await state.clear()
        session_store.clear(message.chat.id)
        await message.answer("PDF was retrieved but could not be delivered in Telegram. Try /restart.")
        return
    analytics.apply_metrics(message.chat.id, pdf_delta=1, fire_cooldown=True)
    session_store.clear(message.chat.id)
    await state.set_state(RetrieveEidFlow.await_mode)
    await message.answer(
        "<b>Finished</b>\nThank you â€” choose your next step below.",
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_keyboard(show_access_notice=show_access_notice_button(message.chat.id)),
    )


@router.message(Command("id"))
async def handle_get_id(message: Message):
    uid = message.from_user.id if message.from_user else message.chat.id
    await message.reply(f"Your Chat ID is: <code>{uid}</code>", parse_mode=ParseMode.HTML)


@router.message()
async def fallback(message: Message) -> None:
    await message.answer(
        "<b>Aadhaar Helper</b>\n"
        "Send /start to open the menu and choose a service.",
        parse_mode=ParseMode.HTML,
        reply_markup=cancel_only_keyboard(),
    )


@router.message.middleware()
async def _service_access_gate(handler, event: Message, data: dict[str, Any]) -> Any:
    return await handler(event, data)

@router.callback_query.middleware()
async def _callback_access_gate(handler, event: CallbackQuery, data: dict[str, Any]) -> Any:
    return await handler(event, data)

async def main() -> None:
    log.info("bot_start log_level=%s backend=%s", settings.log_level, settings.uidai_http_backend)
    if settings.captcha_auto_solve:
        has_gemini = bool(settings.gemini_api_key and settings.gemini_api_key.strip())
        if has_gemini:
            from services.captcha_gemini_solver import gemini_sdk_available

            log.info(
                "captcha_auto_solve=ON gemini_models=%s sdk_import_ok=%s timeout_sec=%s parallel=%s parallel_max=%s failure_log=%s",
                ",".join(settings.gemini_captcha_models),
                gemini_sdk_available(),
                settings.gemini_captcha_timeout_seconds,
                settings.gemini_captcha_parallel,
                settings.gemini_captcha_parallel_max,
                settings.admin_failure_log_file,
            )

        tess_ok, tess_msg = await asyncio.to_thread(check_tesseract_available, settings.tesseract_cmd)
        if tess_ok:
            log.info(
                "captcha_tesseract_fallback_ok=%s attempts=%s ocr_high_conf=%s ocr_consensus_floor=%s votes=%s",
                tess_msg,
                settings.captcha_auto_solve_attempts,
                settings.captcha_ocr_min_confidence,
                settings.captcha_ocr_consensus_confidence,
                settings.captcha_ocr_consensus_votes,
            )
        elif not has_gemini:
            log.warning(
                "captcha_auto_solve=ON but Tesseract unusable (%s). "
                "Install Tesseract OCR or set TESSERACT_CMD â€” or set GEMINI_API_KEY for vision solving.",
                tess_msg,
            )
        else:
            log.warning(
                "captcha_tesseract unavailable (%s); relying on Gemini only for captcha reads.",
                tess_msg,
            )
    bot = Bot(token=settings.telegram_bot_token)
    dp = Dispatcher()
    dp.include_router(build_admin_router(settings, analytics, runtime_policy, dynamic_access, failure_log))
    dp.include_router(router)


    await uidai_client.open()
    await uidai_client.diagnose_connectivity()
    try:
        await dp.start_polling(bot)
    finally:
        await uidai_client.close()


if __name__ == "__main__":
    asyncio.run(main())