


























# AdharBot Retrieve EID (aiogram)

This bot automates the captured Retrieve EID flow:
- Generate captcha
- Ask user to solve captcha
- Send OTP request
- Ask user OTP
- Verify OTP and retrieve EID

## Setup

1. Create virtual environment and install dependencies:
   - `python -m venv .venv`
   - `.venv\Scripts\activate`
   - `pip install -r requirements.txt`
2. Copy `.env.example` to `.env`
3. Put your real Telegram bot token in `.env`
4. Run:
   - `python bot.py`

## Notes

- `dob` is hardcoded as `null` in both OTP send and OTP verify payloads.
- Sensitive fields (full mobile, OTP, captcha) are not stored in logs.
- Successful results are appended to `results.jsonl`.

### Captcha: image only (recommended)

Set in `.env`:

- `CAPTCHA_AUDIO_REQUIRED=false`

The bot only needs the image for Telegram users. Disabling audio reduces JSON payload size from UIDAI. If the API ever rejects this flag, set it back to `true`.

## Network diagnostics (Windows)

If logs show `ReadError`, `ConnectTimeout`, or intermittent TCP while HTTPS fails:

1. From the project folder, run:

   - `powershell -ExecutionPolicy Bypass -File .\scripts\network_diag.ps1`

2. Compare with bot logs:

   - `connectivity_diag dns ...`
   - `connectivity_diag tcp_ok` vs `tcp_failed`

3. Typical causes when TCP works but HTTPS `ReadError` repeats:

   - Unstable ISP routing to the CDN edge
   - Corporate firewall / SSL inspection interfering with some TLS flows
   - Try another network (mobile hotspot vs fiber), or stable wired connection

This is standard path troubleshooting, not application evasion.

## Debugging / logs

While developing, use **`LOG_LEVEL=DEBUG`** (default in `.env.example`). Logs go to:

- **Console** (if `LOG_TO_CONSOLE=true`)
- **Rotating file** `logs/adharbot.log` (5 MB × 5 backups)

Each UIDAI call logs:

- Operation name (`captcha_generation`, `otp_request`, `otp_verify`)
- HTTP status, latency, response size, content-type
- Parsed JSON keys on success; **never** full `imageBase64` / `audioBase64`
- On failure: HTTP body snippet (often HTML or JSON error), JSON decode errors with preview

If captcha generation fails, open `logs/adharbot.log` and search for `captcha_generation` — you will see whether the failure is TLS/network (timeouts), HTTP 4xx/5xx, or non-JSON/HTML response.

## Commands

- `/start` - begin flow
- `/netcheck` - run DNS/TCP connectivity diagnostics to UIDAI host
- `/cancel` - cancel current run
- `/restart` - start fresh
- `/help` - show commands
