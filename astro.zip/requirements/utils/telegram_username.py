"""Validate Telegram @username (public username, 5–32 chars)."""

from __future__ import annotations

import re

_TELEGRAM_USERNAME = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]{3,31}$")


def normalize_username(raw: str | None) -> str | None:
    if not raw:
        return None
    s = raw.strip().lstrip("@")
    if not s:
        return None
    if _TELEGRAM_USERNAME.fullmatch(s):
        return s
    return None
