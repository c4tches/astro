"""Redact or summarize values for safe logging (no secrets, no huge payloads)."""

from __future__ import annotations

import re
from typing import Any, Mapping, Optional


SENSITIVE_KEYS = frozenset(
    {
        "captcha",
        "otp",
        "authtoken",
        "authorization",
        "password",
        "token",
    }
)

_UUID_PREFIX = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)


def short_request_id(value: str) -> str:
    s = (value or "").strip()
    if not s:
        return ""
    if _UUID_PREFIX.match(s):
        return f"{s[:8]}…{s[-4:]}"
    if len(s) <= 12:
        return s
    return f"{s[:6]}…{s[-2:]}"


def mask_mobile_for_log(mobile: str) -> str:
    d = re.sub(r"\D", "", mobile or "")
    if len(d) < 4:
        return "***"
    return f"{d[:2]}******{d[-2:]}"


def redact_json_body(obj: Any) -> Any:
    """Return a log-safe copy of JSON-like data (redact long strings in known keys)."""
    if isinstance(obj, Mapping):
        return {k: _redact_value(k, v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact_json_body(x) for x in obj[:20]] + (["..."] if len(obj) > 20 else [])
    return obj


def _redact_value(key: str, value: Any) -> Any:
    lk = str(key).lower()
    if lk in SENSITIVE_KEYS and isinstance(value, str):
        return f"<redacted len={len(value)}>"
    if lk == "mobilenumber" and value is not None:
        return mask_mobile_for_log(str(value))
    if isinstance(value, str) and len(value) > 120:
        return f"<str len={len(value)} preview={value[:40]}…>"
    if isinstance(value, Mapping):
        return redact_json_body(value)
    if isinstance(value, list):
        return redact_json_body(value)
    return value


def summarize_captcha_response_keys(data: Mapping[str, Any]) -> dict[str, Any]:
    """Summarize UIDAI captcha JSON without dumping base64."""
    out: dict[str, Any] = {}
    for k in sorted(data.keys()):
        v = data[k]
        if k in ("imageBase64", "audioBase64") and isinstance(v, str):
            out[k] = f"<base64 len={len(v)}>"
        elif isinstance(v, str) and len(v) > 80:
            out[k] = f"<str len={len(v)} preview={v[:30]}…>"
        else:
            out[k] = v
    return out


def snippet(text: str, max_len: int = 400) -> str:
    t = (text or "").replace("\r", " ").replace("\n", " ")
    if len(t) <= max_len:
        return t
    return t[:max_len] + "…"


def format_body_for_log(text: str, *, max_len: int = 2500) -> str:
    """Parse JSON when possible, redact sensitive fields, then truncate for logs."""
    import json

    t = (text or "").strip()
    if not t:
        return "<empty body>"
    try:
        obj = json.loads(t)
        if isinstance(obj, (dict, list)):
            safe = redact_json_body(obj)
            out = json.dumps(safe, ensure_ascii=False)
            return snippet(out, max_len)
    except json.JSONDecodeError:
        pass
    return snippet(t, max_len)
