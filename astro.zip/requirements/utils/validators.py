import re


MOBILE_REGEX = re.compile(r"^[6-9]\d{9}$")
NAME_REGEX = re.compile(r"^[A-Za-z ]{2,60}$")
CAPTCHA_REGEX = re.compile(r"^[A-Za-z0-9]{4,12}$")
UIDAI_CAPTCHA_6_REGEX = re.compile(r"^[A-Za-z0-9]{6}$")
OTP_REGEX = re.compile(r"^\d{6}$")
EID_REGEX = re.compile(r"^\d{28}$")


def normalize_mobile(raw: str) -> str:
    return re.sub(r"\D", "", raw or "")


def validate_mobile(raw: str) -> tuple[bool, str]:
    mobile = normalize_mobile(raw)
    if not MOBILE_REGEX.fullmatch(mobile):
        return False, ""
    return True, mobile


def normalize_name(raw: str) -> str:
    cleaned = re.sub(r"\s+", " ", (raw or "").strip())
    return cleaned


def validate_name(raw: str) -> tuple[bool, str]:
    name = normalize_name(raw)
    if not NAME_REGEX.fullmatch(name):
        return False, ""
    return True, name


def validate_captcha(raw: str) -> tuple[bool, str]:
    text = (raw or "").strip()
    if not CAPTCHA_REGEX.fullmatch(text):
        return False, ""
    return True, text


def validate_uidai_captcha_strict(raw: str | None) -> tuple[bool, str]:
    """UIDAI generation uses captchaLength=6 alphanumeric (for OCR auto-solve)."""
    if not raw:
        return False, ""
    text = "".join(c for c in raw.strip() if c.isalnum())
    if not UIDAI_CAPTCHA_6_REGEX.fullmatch(text):
        return False, ""
    return True, text


def validate_otp(raw: str) -> tuple[bool, str]:
    otp = normalize_mobile(raw)
    if not OTP_REGEX.fullmatch(otp):
        return False, ""
    return True, otp


def validate_eid(raw: str) -> tuple[bool, str]:
    eid = re.sub(r"\D", "", raw or "")
    if not EID_REGEX.fullmatch(eid):
        return False, ""
    return True, eid


def mask_mobile(mobile: str) -> str:
    if len(mobile) < 4:
        return "***"
    return f"{mobile[:2]}******{mobile[-2:]}"
