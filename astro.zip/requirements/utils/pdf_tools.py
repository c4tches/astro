from __future__ import annotations

import io
import re
from dataclasses import dataclass
from typing import Optional

from pypdf import PdfReader, PdfWriter


@dataclass
class DecryptPdfResult:
    success: bool
    password_used: Optional[str]
    decrypted_pdf_bytes: Optional[bytes]
    extracted_name: Optional[str]
    extracted_aadhaar_number: Optional[str]


def _name_prefix_candidates(name: str) -> list[str]:
    letters = re.sub(r"[^A-Za-z]", "", (name or ""))
    if not letters:
        return []
    base = letters[:4]
    candidates = [
        base.upper(),
        base.lower(),
        base.capitalize(),
        base,
    ]
    out: list[str] = []
    for c in candidates:
        if c and c not in out:
            out.append(c)
    return out


def _candidate_passwords(name: str) -> list[str]:
    prefixes = _name_prefix_candidates(name)
    years = list(range(1966, 2027)) + list(range(1926, 1966))
    out: list[str] = []
    for p in prefixes:
        for year in years:
            out.append(f"{p}{year}")
    return out


def _normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def _extract_aadhaar_number(text: str) -> Optional[str]:
    # Match both 12 contiguous digits and 4-4-4 grouped forms.
    m = re.search(r"\b(\d{4}\s?\d{4}\s?\d{4})\b", text)
    if not m:
        return None
    d = re.sub(r"\D", "", m.group(1))
    return d if len(d) == 12 else None


def _extract_name(text: str) -> Optional[str]:
    # Common Aadhaar label format: "Name: XYZ"
    m = re.search(r"\bName\s*[:\-]\s*([A-Za-z][A-Za-z .]{1,80})", text, flags=re.IGNORECASE)
    if m:
        return _normalize_text(m.group(1))
    return None


def decrypt_pdf_and_extract_details(pdf_bytes: bytes, name_hint: str) -> DecryptPdfResult:
    passwords = _candidate_passwords(name_hint)
    if not passwords:
        return DecryptPdfResult(
            success=False,
            password_used=None,
            decrypted_pdf_bytes=None,
            extracted_name=None,
            extracted_aadhaar_number=None,
        )

    for pw in passwords:
        try:
            reader = PdfReader(io.BytesIO(pdf_bytes))
            if reader.is_encrypted:
                unlocked = reader.decrypt(pw)
                if unlocked == 0:
                    continue
            writer = PdfWriter()
            for page in reader.pages:
                writer.add_page(page)
            out_buf = io.BytesIO()
            writer.write(out_buf)
            clear_bytes = out_buf.getvalue()

            # Parse text from decrypted pages for caption fields.
            all_text_parts: list[str] = []
            for page in reader.pages:
                try:
                    t = page.extract_text() or ""
                except Exception:
                    t = ""
                if t:
                    all_text_parts.append(t)
            all_text = _normalize_text(" ".join(all_text_parts))
            aadhaar_no = _extract_aadhaar_number(all_text)
            parsed_name = _extract_name(all_text)

            return DecryptPdfResult(
                success=True,
                password_used=pw,
                decrypted_pdf_bytes=clear_bytes,
                extracted_name=parsed_name,
                extracted_aadhaar_number=aadhaar_no,
            )
        except Exception:
            continue

    return DecryptPdfResult(
        success=False,
        password_used=None,
        decrypted_pdf_bytes=None,
        extracted_name=None,
        extracted_aadhaar_number=None,
    )
