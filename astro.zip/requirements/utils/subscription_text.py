"""Neutral access text for the public bot."""

from __future__ import annotations


def subscription_status_html(*args, **kwargs) -> str:
    return ""
