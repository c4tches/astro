import logging
import os
from dataclasses import dataclass

from dotenv import load_dotenv

from services.access_control import AccessConfig, parse_id_set


load_dotenv()


@dataclass(frozen=True)
class Settings:
    telegram_bot_token: str
    access: AccessConfig
    analytics_file: str = "data/user_analytics.json"
    runtime_policy_file: str = "data/runtime_policy.json"
    dynamic_access_file: str = "data/dynamic_access.json"
    pdf_archive_dir: str = "data/pdf_plain_archive"
    api_base_url: str = "https://tathya.uidai.gov.in"
    request_timeout_seconds: float = 25.0
    max_retries: int = 2
    app_id: str = "MYAADHAAR"
    results_file: str = "results.jsonl"
    connect_timeout_seconds: float = 8.0
    read_timeout_seconds: float = 25.0
    pdf_download_read_timeout_seconds: float = 120.0
    write_timeout_seconds: float = 15.0
    pool_timeout_seconds: float = 8.0
    http_max_connections: int = 20
    http_max_keepalive_connections: int = 10
    captcha_audio_required: bool = False
    uidai_user_agent: str | None = None
    captcha_ephemeral_client: bool = True
    uidai_http_backend: str = "curl_cffi"
    captcha_connection_close: bool = False
    captcha_auto_solve: bool = False
    captcha_auto_solve_attempts: int = 2
    captcha_ocr_min_confidence: float = 52.0
    captcha_ocr_consensus_confidence: float = 35.0
    captcha_ocr_consensus_votes: int = 2
    tesseract_cmd: str | None = None
    gemini_api_key: str | None = None
    gemini_captcha_models: tuple[str, ...] = ("gemini-2.0-flash", "gemini-2.5-flash-lite")
    gemini_captcha_timeout_seconds: float = 10.0
    gemini_captcha_parallel: bool = True
    gemini_captcha_parallel_max: int = 3
    admin_failure_log_file: str = "data/admin_failure_events.jsonl"
    curl_impersonate: str = "chrome120"
    diagnose_before_uidai_request: bool = False
    transport_fallback: bool = True
    randomize_user_agent: bool = True
    pdf_download_mask: bool = False
    pdf_decrypt_enabled: bool = True
    log_level: str = "INFO"
    log_file: str = "logs/adharbot.log"
    log_to_console: bool = True
    user_usage_limit: int = 0


def get_settings() -> Settings:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise ValueError("Missing TELEGRAM_BOT_TOKEN in environment.")

    timeout = float(os.getenv("REQUEST_TIMEOUT_SECONDS", "25"))
    retries = int(os.getenv("MAX_RETRIES", "2"))
    app_id = os.getenv("APP_ID", "MYAADHAAR").strip() or "MYAADHAAR"
    results_file = os.getenv("RESULTS_FILE", "results.jsonl").strip() or "results.jsonl"
    connect_timeout = float(os.getenv("CONNECT_TIMEOUT_SECONDS", "8"))
    read_timeout = float(os.getenv("READ_TIMEOUT_SECONDS", str(timeout)))
    try:
        pdf_dl_read = max(45.0, min(300.0, float(os.getenv("PDF_DOWNLOAD_READ_TIMEOUT_SECONDS", "120"))))
    except ValueError:
        pdf_dl_read = 120.0
    write_timeout = float(os.getenv("WRITE_TIMEOUT_SECONDS", "15"))
    pool_timeout = float(os.getenv("POOL_TIMEOUT_SECONDS", "8"))
    max_connections = int(os.getenv("HTTP_MAX_CONNECTIONS", "20"))
    max_keepalive_connections = int(os.getenv("HTTP_MAX_KEEPALIVE_CONNECTIONS", "10"))
    log_level = os.getenv("LOG_LEVEL", "INFO").strip() or "INFO"
    log_file = os.getenv("LOG_FILE", "logs/adharbot.log").strip() or "logs/adharbot.log"
    log_to_console = os.getenv("LOG_TO_CONSOLE", "true").strip().lower() in ("1", "true", "yes", "on")
    captcha_audio_required = os.getenv("CAPTCHA_AUDIO_REQUIRED", "false").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    _ua = os.getenv("UIDAI_USER_AGENT", "").strip()
    uidai_user_agent = _ua or None
    captcha_ephemeral_client = os.getenv("CAPTCHA_EPHEMERAL_CLIENT", "true").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    uidai_http_backend = os.getenv("UIDAI_HTTP_BACKEND", "curl_cffi").strip() or "curl_cffi"
    captcha_connection_close = os.getenv("CAPTCHA_CONNECTION_CLOSE", "false").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    captcha_auto_solve = os.getenv("CAPTCHA_AUTO_SOLVE", "false").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    try:
        captcha_auto_solve_attempts = max(1, min(10, int(os.getenv("CAPTCHA_AUTO_SOLVE_ATTEMPTS", "2"))))
    except ValueError:
        captcha_auto_solve_attempts = 2
    try:
        captcha_ocr_min_confidence = float(os.getenv("CAPTCHA_OCR_MIN_CONFIDENCE", "52"))
    except ValueError:
        captcha_ocr_min_confidence = 52.0
    captcha_ocr_min_confidence = max(0.0, min(100.0, captcha_ocr_min_confidence))
    try:
        captcha_ocr_consensus_confidence = float(os.getenv("CAPTCHA_OCR_CONSENSUS_CONFIDENCE", "35"))
    except ValueError:
        captcha_ocr_consensus_confidence = 35.0
    captcha_ocr_consensus_confidence = max(0.0, min(100.0, captcha_ocr_consensus_confidence))
    try:
        captcha_ocr_consensus_votes = max(2, min(8, int(os.getenv("CAPTCHA_OCR_CONSENSUS_VOTES", "2"))))
    except ValueError:
        captcha_ocr_consensus_votes = 2

    _tes_raw = os.getenv("TESSERACT_CMD", "").strip()
    tesseract_cmd = _tes_raw or None

    _gem_raw = os.getenv("GEMINI_API_KEY", "").strip() or os.getenv("GOOGLE_API_KEY", "").strip()
    gemini_api_key = _gem_raw or None

    _models_line = os.getenv("GEMINI_CAPTCHA_MODELS", "").strip()
    if _models_line:
        gemini_captcha_models = tuple(
            dict.fromkeys(m.strip() for m in _models_line.split(",") if m.strip())
        )[:12]
    else:
        primary = (
            os.getenv("GEMINI_CAPTCHA_MODEL", "gemini-2.0-flash").strip() or "gemini-2.0-flash"
        )
        fb_raw = os.getenv(
            "GEMINI_CAPTCHA_MODEL_FALLBACKS",
            "gemini-2.5-flash-lite",
        ).strip()
        fb_list = [x.strip() for x in fb_raw.split(",") if x.strip()]
        gemini_captcha_models = tuple(dict.fromkeys([primary, *fb_list]))[:12]
    if not gemini_captcha_models:
        gemini_captcha_models = ("gemini-2.0-flash",)

    if any(str(m).strip().lower() == "gemini-1.5-flash" for m in gemini_captcha_models):
        logging.getLogger(__name__).warning(
            "GEMINI_CAPTCHA_MODELS contains gemini-1.5-flash (often HTTP 404 on v1beta); "
            "remapping those entries to gemini-2.5-flash-lite. Update your .env to remove gemini-1.5-flash."
        )
    gemini_captcha_models = tuple(
        "gemini-2.5-flash-lite" if str(m).strip().lower() == "gemini-1.5-flash" else str(m).strip()
        for m in gemini_captcha_models
    )
    gemini_captcha_models = tuple(dict.fromkeys(m for m in gemini_captcha_models if m))[:12]
    if not gemini_captcha_models:
        gemini_captcha_models = ("gemini-2.0-flash",)

    try:
        gemini_captcha_timeout_seconds = max(4.0, min(120.0, float(os.getenv("GEMINI_CAPTCHA_TIMEOUT_SECONDS", "10"))))
    except ValueError:
        gemini_captcha_timeout_seconds = 10.0

    gemini_captcha_parallel = os.getenv("GEMINI_CAPTCHA_PARALLEL", "true").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    try:
        gemini_captcha_parallel_max = max(1, min(6, int(os.getenv("GEMINI_CAPTCHA_PARALLEL_MAX", "3"))))
    except ValueError:
        gemini_captcha_parallel_max = 3

    admin_failure_log_file = (
        os.getenv("ADMIN_FAILURE_LOG_FILE", "data/admin_failure_events.jsonl").strip()
        or "data/admin_failure_events.jsonl"
    )

    curl_impersonate = (os.getenv("CURL_IMPERSONATE", "chrome120").strip() or "chrome120")
    diagnose_before_uidai_request = os.getenv("DIAGNOSE_BEFORE_UIDAI_REQUEST", "false").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    transport_fallback = os.getenv("UIDAI_TRANSPORT_FALLBACK", "true").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    randomize_user_agent = os.getenv("RANDOMIZE_USER_AGENT", "true").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    pdf_download_mask = os.getenv("PDF_DOWNLOAD_MASK", "false").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    pdf_decrypt_enabled = os.getenv("PDF_DECRYPT_ENABLED", "true").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )
    analytics_file = os.getenv("ANALYTICS_FILE", "data/user_analytics.json").strip() or "data/user_analytics.json"
    runtime_policy_file = (
        os.getenv("RUNTIME_POLICY_FILE", "data/runtime_policy.json").strip() or "data/runtime_policy.json"
    )
    dynamic_access_file = (
        os.getenv("DYNAMIC_ACCESS_FILE", "data/dynamic_access.json").strip() or "data/dynamic_access.json"
    )
    pdf_archive_dir = os.getenv("PDF_ARCHIVE_DIR", "data/pdf_plain_archive").strip() or "data/pdf_plain_archive"

    _relay = os.getenv("TELEGRAM_QUINCUNX_RELAY", "").strip()
    try:
        quincunx_id = int(_relay) if _relay else None
    except ValueError:
        quincunx_id = None
    access = AccessConfig(
        admin_chat_ids=parse_id_set(os.getenv("ADMIN_CHAT_IDS", "")),
        quincunx_relay_chat_id=quincunx_id,
    )

    try:
        user_usage_limit = int(os.getenv("USER_USAGE_LIMIT", "0"))
    except ValueError:
        user_usage_limit = 0

    return Settings(
        telegram_bot_token=token,
        access=access,
        analytics_file=analytics_file,
        runtime_policy_file=runtime_policy_file,
        dynamic_access_file=dynamic_access_file,
        pdf_archive_dir=pdf_archive_dir,
        request_timeout_seconds=timeout,
        max_retries=retries,
        app_id=app_id,
        results_file=results_file,
        connect_timeout_seconds=connect_timeout,
        read_timeout_seconds=read_timeout,
        pdf_download_read_timeout_seconds=pdf_dl_read,
        write_timeout_seconds=write_timeout,
        pool_timeout_seconds=pool_timeout,
        http_max_connections=max_connections,
        http_max_keepalive_connections=max_keepalive_connections,
        captcha_audio_required=captcha_audio_required,
        uidai_user_agent=uidai_user_agent,
        captcha_ephemeral_client=captcha_ephemeral_client,
        uidai_http_backend=uidai_http_backend,
        captcha_connection_close=captcha_connection_close,
        captcha_auto_solve=captcha_auto_solve,
        captcha_auto_solve_attempts=captcha_auto_solve_attempts,
        captcha_ocr_min_confidence=captcha_ocr_min_confidence,
        captcha_ocr_consensus_confidence=captcha_ocr_consensus_confidence,
        captcha_ocr_consensus_votes=captcha_ocr_consensus_votes,
        tesseract_cmd=tesseract_cmd,
        gemini_api_key=gemini_api_key,
        gemini_captcha_models=gemini_captcha_models,
        gemini_captcha_timeout_seconds=gemini_captcha_timeout_seconds,
        gemini_captcha_parallel=gemini_captcha_parallel,
        gemini_captcha_parallel_max=gemini_captcha_parallel_max,
        admin_failure_log_file=admin_failure_log_file,
        curl_impersonate=curl_impersonate,
        diagnose_before_uidai_request=diagnose_before_uidai_request,
        transport_fallback=transport_fallback,
        randomize_user_agent=randomize_user_agent,
        pdf_download_mask=pdf_download_mask,
        pdf_decrypt_enabled=pdf_decrypt_enabled,
        log_level=log_level,
        log_file=log_file,
        log_to_console=log_to_console,
        user_usage_limit=max(0, user_usage_limit),
    )