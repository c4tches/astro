# UIDAI host connectivity diagnostics (Windows PowerShell).
# Run from repo folder:  .\scripts\network_diag.ps1

$ErrorActionPreference = "Continue"
$HostName = "tathya.uidai.gov.in"
$Port = 443

Write-Host "=== DNS ===" -ForegroundColor Cyan
try {
    Resolve-DnsName $HostName -ErrorAction Stop | Format-Table -AutoSize
} catch {
    Write-Host "DNS failed: $_" -ForegroundColor Red
}

Write-Host "`n=== TCP test (443) ===" -ForegroundColor Cyan
try {
    Test-NetConnection -ComputerName $HostName -Port $Port -WarningAction Continue |
        Format-List ComputerName, RemoteAddress, RemotePort, TcpTestSucceeded, PingSucceeded
} catch {
    Write-Host "Test-NetConnection failed: $_" -ForegroundColor Red
}

Write-Host "`n=== Traceroute (max 15 hops, may take a minute) ===" -ForegroundColor Cyan
try {
    tracert -d -h 15 $HostName
} catch {
    Write-Host "tracert failed: $_" -ForegroundColor Red
}

Write-Host "`nDone. Interpretation:" -ForegroundColor Yellow
Write-Host "- TcpTestSucceeded=False -> firewall/ISP/route blocks or ICMP filtered (still try HTTPS)." 
Write-Host "- Traceroute stalls at one hop repeatedly -> routing or middlebox issue."
Write-Host "- DNS returns multiple IPs over time -> normal CDN; compare with bot logs connectivity_diag."
