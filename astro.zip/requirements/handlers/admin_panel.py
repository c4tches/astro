"""Telegram admin panel (stats, users, delegate admins, failures, broadcast)."""

from __future__ import annotations

import html
from datetime import datetime, timezone

from aiogram import F, Router
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from config import Settings
from services.access_control import is_operator, is_super_admin
from services.admin_failure_log import AdminFailureLog
from services.analytics_store import AnalyticsStore, UserMetrics
from services.dynamic_access_store import DynamicAccessStore
from services.runtime_policy import RuntimePolicyStore

USERS_PAGE_SIZE = 8
_FAILURE_LOG_PAGE_SIZE = 8

_DELEGATE_DURATION = {
    "d24h": 24 * 3600,
    "d7": 7 * 86400,
    "d30": 30 * 86400,
    "d90": 90 * 86400,
    "d365": 365 * 86400,
    "perm": 0,
}


class AdminFlow(StatesGroup):
    await_broadcast = State()


class AdminDelegateGrant(StatesGroup):
    await_tg_id = State()
    await_pick = State()


def _fmt_ts(ts: float | None) -> str:
    if ts is None:
        return "—"
    return datetime.fromtimestamp(float(ts), tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


def _user_public_label(u: UserMetrics) -> str:
    if u.username:
        return f"@{u.username}"
    if u.full_name:
        return u.full_name
    return "—"


def _main_panel_kb(settings: Settings, dyn: DynamicAccessStore, uid: int) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton(text="📊 Statistics", callback_data="adm:stats"),
            InlineKeyboardButton(text="👥 All users", callback_data="adm:ulist:0"),
        ],
    ]
    if is_super_admin(settings.access, uid):
        rows.append([InlineKeyboardButton(text="🛡 Operators", callback_data="adm:op:home")])
    rows.append([InlineKeyboardButton(text="📉 Recent failures", callback_data="adm:fail:0")])
    rows.append([
        InlineKeyboardButton(text="📣 Broadcast", callback_data="adm:broadcast"),
        InlineKeyboardButton(text="✖️ Close", callback_data="adm:close"),
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _operators_menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Add operator", callback_data="adm:op:add")],
        [InlineKeyboardButton(text="📋 Active delegates", callback_data="adm:op:list:0")],
        [InlineKeyboardButton(text="⬅️ Operator home", callback_data="adm:home")],
    ])


def _delegate_duration_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="24 h", callback_data="adm:dk:d24h"), InlineKeyboardButton(text="7 d", callback_data="adm:dk:d7")],
        [InlineKeyboardButton(text="30 d", callback_data="adm:dk:d30"), InlineKeyboardButton(text="90 d", callback_data="adm:dk:d90")],
        [InlineKeyboardButton(text="1 y", callback_data="adm:dk:d365"), InlineKeyboardButton(text="♾ Permanent", callback_data="adm:dk:perm")],
        [InlineKeyboardButton(text="⛔ Cancel", callback_data="adm:op:abort")],
    ])


def build_admin_router(
    settings: Settings,
    analytics: AnalyticsStore,
    policy: RuntimePolicyStore,
    dyn: DynamicAccessStore,
    failure_log: AdminFailureLog,
) -> Router:
    r = Router()

    def adm_only(uid: int) -> bool:
        return is_operator(settings.access, dyn, uid)

    @r.message(Command("panel"))
    @r.message(Command("panal"))
    async def admin_home(message: Message, state: FSMContext) -> None:
        if not message.from_user or not adm_only(message.from_user.id):
            await message.answer("Not authorized.")
            return
        await state.clear()
        await message.answer(
            "<b>Operator console — Aadhaar Helper</b>\n"
            "Statistics, users, delegate operators, failures and broadcast.",
            parse_mode=ParseMode.HTML,
            reply_markup=_main_panel_kb(settings, dyn, message.from_user.id),
        )

    @r.callback_query(F.data == "adm:home")
    async def adm_home_cb(cq: CallbackQuery, state: FSMContext) -> None:
        if not cq.from_user or not adm_only(cq.from_user.id):
            await cq.answer("Not authorized.", show_alert=True)
            return
        await state.clear()
        await cq.answer()
        if cq.message:
            await cq.message.edit_text(
                "<b>Operator console — Aadhaar Helper</b>\n"
                "Statistics, users, delegate operators, failures and broadcast.",
                parse_mode=ParseMode.HTML,
                reply_markup=_main_panel_kb(settings, dyn, cq.from_user.id),
            )

    @r.callback_query(F.data == "adm:close")
    async def adm_close(cq: CallbackQuery) -> None:
        await cq.answer()
        if cq.message:
            await cq.message.edit_text("Panel closed. Send /panel anytime.")

    @r.callback_query(F.data == "adm:stats")
    async def adm_stats(cq: CallbackQuery) -> None:
        if not cq.from_user or not adm_only(cq.from_user.id):
            await cq.answer("Not authorized.", show_alert=True)
            return
        await cq.answer()
        s = analytics.stats_summary()
        top = analytics.top_users(limit=5)
        top_lines = []
        for u in top:
            label = html.escape(_user_public_label(u))
            top_lines.append(f"• <code>{u.chat_id}</code> {label} — PDF <code>{u.pdf_downloads}</code> · EID <code>{u.eid_retrievals}</code>")
        top_block = "\n".join(top_lines) if top_lines else "<i>No activity yet.</i>"
        text = (
            "<b>Statistics</b>\n"
            f"Users tracked: <code>{s.get('total_users', 0)}</code>\n"
            f"Total /start opens logged: <code>{s.get('total_menu_starts', 0)}</code>\n"
            f"PDF deliveries: <code>{s.get('total_pdf_downloads', 0)}</code>\n"
            f"EID retrievals: <code>{s.get('total_eid_retrievals', 0)}</code>\n\n"
            "<b>Top users by PDF count</b>\n"
            f"{top_block}"
        )
        if cq.message:
            await cq.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="👥 Full user list", callback_data="adm:ulist:0")],
                [InlineKeyboardButton(text="⬅️ Back", callback_data="adm:home")],
            ]))

    @r.callback_query(F.data.startswith("adm:ulist:"))
    async def adm_user_list(cq: CallbackQuery) -> None:
        if not cq.from_user or not adm_only(cq.from_user.id):
            await cq.answer("Not authorized.", show_alert=True)
            return
        await cq.answer()
        try:
            offset = max(0, int((cq.data or "").split(":")[-1]))
        except ValueError:
            offset = 0
        rows = analytics.all_users_sorted()
        page = rows[offset: offset + USERS_PAGE_SIZE]
        lines = ["<b>Users</b>", f"Total: <code>{len(rows)}</code>\n"]
        for u in page:
            label = html.escape(_user_public_label(u))
            lines.append(f"• <code>{u.chat_id}</code> {label}\nPDF <code>{u.pdf_downloads}</code> · EID <code>{u.eid_retrievals}</code> · last <code>{_fmt_ts(u.last_seen_unix)}</code>")
        if not page:
            lines.append("<i>No users yet.</i>")
        nav: list[InlineKeyboardButton] = []
        if offset > 0:
            nav.append(InlineKeyboardButton(text="◀️", callback_data=f"adm:ulist:{max(0, offset - USERS_PAGE_SIZE)}"))
        if offset + len(page) < len(rows):
            nav.append(InlineKeyboardButton(text="▶️", callback_data=f"adm:ulist:{offset + USERS_PAGE_SIZE}"))
        kb_rows: list[list[InlineKeyboardButton]] = []
        if nav:
            kb_rows.append(nav)
        kb_rows.append([InlineKeyboardButton(text="⬅️ Back", callback_data="adm:home")])
        if cq.message:
            await cq.message.edit_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows))

    @r.callback_query(F.data == "adm:op:home")
    async def adm_op_home(cq: CallbackQuery) -> None:
        if not cq.from_user or not is_super_admin(settings.access, cq.from_user.id):
            await cq.answer("Only the super account can manage operators.", show_alert=True)
            return
        await cq.answer()
        if cq.message:
            await cq.message.edit_text(
                "<b>🛡 Operators</b>\nAdd or remove delegate operators for panel access.",
                parse_mode=ParseMode.HTML,
                reply_markup=_operators_menu_kb(),
            )

    @r.callback_query(F.data == "adm:op:add")
    async def adm_delegate_add_start(cq: CallbackQuery, state: FSMContext) -> None:
        if not cq.from_user or not is_super_admin(settings.access, cq.from_user.id):
            await cq.answer("Only the super account can manage operators.", show_alert=True)
            return
        await cq.answer()
        await state.set_state(AdminDelegateGrant.await_tg_id)
        if cq.message:
            await cq.message.edit_text("<b>Add operator</b>\nSend numeric Telegram ID.", parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⛔ Cancel", callback_data="adm:op:abort")]]))

    @r.callback_query(F.data == "adm:op:abort")
    async def adm_delegate_abort(cq: CallbackQuery, state: FSMContext) -> None:
        await state.clear()
        await cq.answer("Cancelled.")
        if cq.message:
            await cq.message.edit_text("Cancelled.", reply_markup=_operators_menu_kb())

    @r.message(AdminDelegateGrant.await_tg_id, F.text)
    async def adm_delegate_got_id(message: Message, state: FSMContext) -> None:
        if not message.from_user or not is_super_admin(settings.access, message.from_user.id):
            await state.clear()
            await message.answer("Not authorized.")
            return
        raw = (message.text or "").strip()
        if not raw.isdigit():
            await message.answer("Send digits only.")
            return
        await state.update_data(target_uid=int(raw))
        await state.set_state(AdminDelegateGrant.await_pick)
        await message.answer("Choose operator duration:", reply_markup=_delegate_duration_kb())

    @r.callback_query(AdminDelegateGrant.await_pick, F.data.startswith("adm:dk:"))
    async def adm_delegate_pick(cq: CallbackQuery, state: FSMContext) -> None:
        if not cq.from_user or not is_super_admin(settings.access, cq.from_user.id):
            await cq.answer("Not authorized.", show_alert=True)
            return
        code = (cq.data or "").split(":")[-1]
        if code not in _DELEGATE_DURATION:
            await cq.answer("Bad duration.", show_alert=True)
            return
        data = await state.get_data()
        tid = int(data.get("target_uid"))
        until = dyn.grant_delegate_admin(tid, seconds=_DELEGATE_DURATION[code], added_by=cq.from_user.id)
        await state.clear()
        await cq.answer("Saved.")
        until_txt = "Permanent" if until is None else _fmt_ts(until)
        if cq.message:
            await cq.message.edit_text(f"<b>Operator added</b>\nUser: <code>{tid}</code>\nExpiry: <code>{until_txt}</code>", parse_mode=ParseMode.HTML, reply_markup=_operators_menu_kb())

    @r.callback_query(F.data.startswith("adm:op:list:"))
    async def adm_delegate_list(cq: CallbackQuery) -> None:
        if not cq.from_user or not is_super_admin(settings.access, cq.from_user.id):
            await cq.answer("Only the super account can manage operators.", show_alert=True)
            return
        await cq.answer()
        rows = dyn.list_delegate_rows()
        lines = ["<b>Delegate operators</b>", f"Active: <code>{len(rows)}</code>\n"]
        kb_rows: list[list[InlineKeyboardButton]] = []
        for g in rows[:20]:
            exp_txt = "permanent" if g.expires_at is None else _fmt_ts(g.expires_at)
            lines.append(f"• <code>{g.chat_id}</code> — {exp_txt}")
            kb_rows.append([InlineKeyboardButton(text=f"Remove {g.chat_id}", callback_data=f"adm:dr:{g.chat_id}")])
        if not rows:
            lines.append("<i>No delegate operators.</i>")
        kb_rows.append([InlineKeyboardButton(text="⬅️ Operators menu", callback_data="adm:op:home")])
        if cq.message:
            await cq.message.edit_text("\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows))

    @r.callback_query(F.data.startswith("adm:dr:"))
    async def adm_delegate_revoke(cq: CallbackQuery) -> None:
        if not cq.from_user or not is_super_admin(settings.access, cq.from_user.id):
            await cq.answer("Only the super account can manage operators.", show_alert=True)
            return
        try:
            uid = int((cq.data or "").split(":")[-1])
        except ValueError:
            await cq.answer("Bad id.", show_alert=True)
            return
        ok = dyn.revoke_delegate_admin(uid)
        await cq.answer("Removed." if ok else "Not found.")
        if cq.message:
            await cq.message.edit_text((f"Removed operator <code>{uid}</code>." if ok else f"No operator entry for <code>{uid}</code>."), parse_mode=ParseMode.HTML, reply_markup=_operators_menu_kb())

    @r.callback_query(F.data.startswith("adm:fail:"))
    async def adm_failures(cq: CallbackQuery) -> None:
        if not cq.from_user or not adm_only(cq.from_user.id):
            await cq.answer("Not authorized.", show_alert=True)
            return
        await cq.answer()
        rows = failure_log.read_newest(limit=80)
        lines = ["<b>Recent failures</b>\n"]
        for rec in rows[:20]:
            d = html.escape((rec.detail or "")[:160])
            lines.append(f"<code>{html.escape(rec.ts)}</code> · <code>{rec.chat_id}</code>\n<b>{html.escape(rec.kind)}</b> — {d}")
        if not rows:
            lines.append("<i>No entries yet.</i>")
        if cq.message:
            await cq.message.edit_text("\n\n".join(lines), parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⬅️ Back", callback_data="adm:home")]]))

    @r.callback_query(F.data == "adm:broadcast")
    async def adm_broadcast_start(cq: CallbackQuery, state: FSMContext) -> None:
        if not cq.from_user or not adm_only(cq.from_user.id):
            await cq.answer("Not authorized.", show_alert=True)
            return
        await cq.answer()
        await state.set_state(AdminFlow.await_broadcast)
        if cq.message:
            await cq.message.edit_text("Send the broadcast message text. It will be sent by the main bot process where supported.", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="⛔ Cancel", callback_data="adm:home")]]))

    @r.message(AdminFlow.await_broadcast, F.text)
    async def adm_broadcast_received(message: Message, state: FSMContext) -> None:
        if not message.from_user or not adm_only(message.from_user.id):
            await state.clear()
            await message.answer("Not authorized.")
            return
        await state.clear()
        await message.answer("Broadcast text received. Existing deployment can wire this to its sender if needed.", reply_markup=_main_panel_kb(settings, dyn, message.from_user.id))

    return r
